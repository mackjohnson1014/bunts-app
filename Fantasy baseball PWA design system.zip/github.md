repo: mackjohnson1014/bunts-app
branch: main
path: web/

## Last sync
date: 2026-09-15T22:50:36Z

### Updated in this project
- Extracted the Bunts palette, type scale and spacing into token CSS.
- Rebuilt the app's UI primitives as design-system components.
- Copied the app icons and transcribed the ball mark and tab glyphs into assets/.
- Recreated Home, Today, This Week, Roster, Player and Transactions as a UI kit.

## Screen map
| Design system surface | Repo source |
| --- | --- |
| tokens/*.css | web/src/styles.css (:root) |
| components/core/* | web/src/styles.css, web/src/components.tsx |
| components/data/* | web/src/components.tsx, web/src/screens/Matchup.tsx, web/src/screens/Keepers.tsx |
| components/forms/* | web/src/PlayerSheet.tsx, web/src/screens/Settings.tsx |
| components/navigation/* | web/src/App.tsx, web/src/screens/Home.tsx, web/src/components.tsx |
| components/feedback/* | web/src/PlayerSheet.tsx, web/src/InstallBanner.tsx, web/src/App.tsx |
| ui_kits/bunts-pwa/Home | web/src/screens/Home.tsx |
| ui_kits/bunts-pwa/Today | web/src/screens/Today.tsx |
| ui_kits/bunts-pwa/Week | web/src/screens/Matchup.tsx, web/src/scoring/categories.ts |
| ui_kits/bunts-pwa/Roster | web/src/screens/Roster.tsx, web/src/components.tsx |
| ui_kits/bunts-pwa/PlayerSheet | web/src/PlayerSheet.tsx |
| ui_kits/bunts-pwa/Transactions | web/src/screens/Transactions.tsx |
| assets/icons/* | web/src/icons.tsx |
| assets/logo.svg | web/src/Logo.tsx, web/make-icons.py |
