An Item without a status rule: used for errors, permission state, and anything explanatory.

```jsx
<Stack>
  <StatusRow tone="good">Notifications are on for this device.</StatusRow>
  <Muted style={{ marginTop: 8 }}>Quiet hours 11pm - 7am.</Muted>
</Stack>
```

Every empty state is one plain sentence in a Stack or a plain Item. No illustrations, ever.
