import React from 'react';

export function InstallBanner({ open, onToggle, onDismiss, steps = [], children }) {
  return (
    <aside style={{
      flex: 'none', margin: '8px 16px 0', border: '1px solid var(--amber)',
      borderRadius: 'var(--radius-lg)', background: 'var(--surface-accent)', padding: '8px 10px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)' }}>
        <button type="button" onClick={onToggle} aria-expanded={!!open} style={{
          flex: 1, display: 'flex', alignItems: 'center', gap: '7px', background: 'none', border: 0,
          padding: '2px 0', cursor: 'pointer', textAlign: 'left', color: 'var(--amber)',
          fontFamily: 'var(--font-condensed)', fontSize: '14px', fontWeight: 600, letterSpacing: '.04em',
        }}>
          <span aria-hidden="true" style={{ fontSize: 'var(--text-label)' }}>{open ? '\u25be' : '\u25b8'}</span>
          Add Bunts to your home screen
        </button>
        <button type="button" onClick={onDismiss} aria-label="Dismiss install instructions" style={{
          background: 'none', border: 0, cursor: 'pointer', color: 'var(--chalk-dim)',
          fontSize: '20px', lineHeight: 1, padding: '0 4px',
        }}>{'\u00d7'}</button>
      </div>
      {open ? (
        <div>
          <p style={{ margin: '8px 0 0', fontSize: 'var(--text-meta)', color: 'var(--chalk)' }}>
            Installed, Bunts opens like an app and can send you notifications.
          </p>
          {steps.length ? (
            <ol style={{ margin: '8px 0 0', paddingLeft: '20px', fontSize: 'var(--text-verdict)', color: 'var(--chalk-dim)' }}>
              {steps.map((s) => <li key={s} style={{ marginBottom: '5px' }}>{s}</li>)}
            </ol>
          ) : null}
          {children}
        </div>
      ) : null}
    </aside>
  );
}

export function UpdatePill({ onClick }) {
  return (
    <button type="button" onClick={onClick} style={{
      flex: 'none', margin: '8px 16px 0', padding: '9px 12px', background: 'var(--amber)',
      color: 'var(--ink)', border: 0, borderRadius: 'var(--radius-lg)',
      fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-meta)', fontWeight: 700,
      letterSpacing: 'var(--track-btn)', textTransform: 'uppercase', cursor: 'pointer',
      textAlign: 'center', width: 'calc(100% - 32px)',
    }}>New version available {'\u2014'} tap to update</button>
  );
}

export function PreviewBar({ children = 'Preview build · sample data · not connected to your league' }) {
  return (
    <div style={{
      flex: 'none', padding: '6px 16px', background: 'var(--clay)', color: 'var(--text-inverse)',
      fontFamily: 'var(--font-condensed)', fontSize: '11.5px', fontWeight: 600,
      letterSpacing: 'var(--track-chip)', textTransform: 'uppercase', textAlign: 'center',
    }}>{children}</div>
  );
}
