export interface SheetProps {
  open?: boolean;
  /** Condensed uppercase, 26px — usually a player name. */
  title: string;
  /** One line of context under the title. */
  meta?: string;
  onClose?: () => void;
  children?: React.ReactNode;
}

export interface TonightCell {
  label: string;
  value: React.ReactNode;
  tone?: 'good' | 'bad' | 'warn';
}

/**
 * Bottom sheet — the app's only overlay — plus the boxed status strip inside it.
 * @startingPoint section="Feedback" subtitle="Bottom sheet and status strip" viewport="700x400"
 */
export declare function Sheet(props: SheetProps): JSX.Element | null;
export declare function Tonight(props: { cells?: TonightCell[] }): JSX.Element;
