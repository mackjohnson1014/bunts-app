export interface StackProps { children?: React.ReactNode; style?: React.CSSProperties }

export interface StatusRowProps {
  tone?: 'good' | 'bad' | 'warn' | 'neutral';
  children?: React.ReactNode;
}

/**
 * Plain boxed panel for state and explanation, plus its dot row and muted note.
 * @startingPoint section="Feedback" subtitle="Panel, status dot, muted note" viewport="700x200"
 */
export declare function Stack(props: StackProps): JSX.Element;
export declare function StatusRow(props: StatusRowProps): JSX.Element;
export declare function Muted(props: { children?: React.ReactNode; style?: React.CSSProperties }): JSX.Element;
