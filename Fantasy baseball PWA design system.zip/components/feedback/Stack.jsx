import React from 'react';

export function Stack({ children, style }) {
  return (
    <div style={{
      border: '1px solid var(--rule)', borderRadius: 'var(--radius-lg)',
      background: 'var(--board-2)', padding: 'var(--card-pad)', ...style,
    }}>{children}</div>
  );
}

export function StatusRow({ tone = 'neutral', children }) {
  const color = tone === 'good' ? 'var(--grass)' : tone === 'bad' ? 'var(--clay)' : tone === 'warn' ? 'var(--amber)' : 'var(--chalk-dim)';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '9px' }}>
      <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: color, flex: 'none' }} />
      <span>{children}</span>
    </div>
  );
}

export function Muted({ children, style }) {
  return <p style={{ color: 'var(--chalk-dim)', fontSize: 'var(--text-meta)', margin: 0, ...style }}>{children}</p>;
}
