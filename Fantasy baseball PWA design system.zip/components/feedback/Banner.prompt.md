Three app-level strips, all outside the scrolling screen and all dismissible or self-clearing.

```jsx
<PreviewBar />
<UpdatePill onClick={apply} />
<InstallBanner open={open} onToggle={toggle} onDismiss={dismiss} steps={['Tap Share', 'Tap Add to Home Screen']} />
```

Install is amber-outlined on an 8% amber wash. Preview is a solid clay bar — the only solid clay in the product, and only ever on a build that is not connected to the real league.
