export interface InstallBannerProps {
  open?: boolean;
  onToggle?: () => void;
  onDismiss?: () => void;
  /** Manual install steps, used when the browser gives no install prompt. */
  steps?: string[];
  children?: React.ReactNode;
}

/**
 * The three strips that can appear above a screen: install, update, preview.
 * @startingPoint section="Feedback" subtitle="Install, update and preview strips" viewport="700x260"
 */
export declare function InstallBanner(props: InstallBannerProps): JSX.Element;
export declare function UpdatePill(props: { onClick?: () => void }): JSX.Element;
export declare function PreviewBar(props: { children?: React.ReactNode }): JSX.Element;
