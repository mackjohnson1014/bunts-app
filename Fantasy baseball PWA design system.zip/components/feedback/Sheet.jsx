import React from 'react';

export function Sheet({ open = true, title, meta, onClose, children }) {
  if (!open) return null;
  return (
    <div role="presentation" onClick={onClose} style={{
      position: 'absolute', inset: 0, zIndex: 40, background: 'var(--surface-scrim)',
      display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      animation: 'bunts-fade var(--dur-fade) ease-out',
    }}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: 'var(--app-max-width)', maxHeight: '88%',
          background: 'var(--board)', border: '1px solid var(--rule)', borderBottom: 0,
          borderRadius: 'var(--radius-sheet) var(--radius-sheet) 0 0',
          display: 'flex', flexDirection: 'column',
          animation: 'bunts-rise var(--dur-sheet) var(--ease-enter)',
        }}
      >
        <div aria-hidden="true" style={{
          width: '36px', height: '4px', borderRadius: '2px', background: 'var(--rule)',
          margin: '8px auto 0', flex: 'none',
        }} />
        <div style={{
          display: 'flex', alignItems: 'flex-start', gap: 'var(--space-4)',
          padding: '10px 16px 12px', borderBottom: 'var(--hairline)', flex: 'none',
        }}>
          <div>
            <h2 style={{
              fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-sheet-name)', fontWeight: 700,
              lineHeight: 1, margin: 0, textTransform: 'uppercase', letterSpacing: 'var(--track-title)',
            }}>{title}</h2>
            {meta ? (
              <p style={{
                margin: '5px 0 0', fontSize: 'var(--text-statline)', color: 'var(--chalk-dim)',
                fontFamily: 'var(--font-condensed)', letterSpacing: 'var(--track-tight)',
              }}>{meta}</p>
            ) : null}
          </div>
          <button type="button" onClick={onClose} aria-label="Close" style={{
            marginLeft: 'auto', background: 'none', border: 0, cursor: 'pointer',
            color: 'var(--chalk-dim)', fontSize: '26px', lineHeight: 1, padding: '0 4px',
          }}>{'\u00d7'}</button>
        </div>
        <div style={{ overflowY: 'auto', padding: '4px 16px 20px' }}>{children}</div>
      </div>
    </div>
  );
}

export function Tonight({ cells = [] }) {
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: 'repeat(' + cells.length + ', 1fr)',
      border: '1px solid var(--rule)', borderRadius: 'var(--radius-md)', overflow: 'hidden',
    }}>
      {cells.map((c, i) => (
        <div key={c.label} style={{ padding: '9px 8px', borderRight: i === cells.length - 1 ? 0 : '1px solid var(--rule)', minWidth: 0 }}>
          <span style={{
            display: 'block', fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-slate-key)',
            letterSpacing: 'var(--track-key)', textTransform: 'uppercase', color: 'var(--chalk-dim)',
          }}>{c.label}</span>
          <span style={{
            display: 'block', fontSize: 'var(--text-verdict)', marginTop: '3px',
            color: c.tone === 'good' ? 'var(--grass)' : c.tone === 'bad' ? 'var(--clay)' : c.tone === 'warn' ? 'var(--amber)' : 'var(--chalk)',
          }}>{c.value}</span>
        </div>
      ))}
    </div>
  );
}
