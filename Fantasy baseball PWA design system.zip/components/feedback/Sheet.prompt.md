Detail lives in a sheet, never a new screen: a row can carry a name, a slot and five numbers, and everything explaining *why* goes here.

```jsx
<Sheet title="Gunnar Henderson" meta="BAL · SS/3B · slot SS · 99% rostered" onClose={close}>
  <Tonight cells={[{ label: 'Status', value: 'In the lineup', tone: 'good' }]} />
</Sheet>
```

Rises 14px with a fade, 220ms, cubic-bezier(.2,.8,.3,1). Escape and a backdrop tap both close it. Inside a fixed app frame use `position: absolute`; in a real viewport it is `fixed`.
