The week's scoreboard, one category per row. The status colour runs down the left edge like an Item.

```jsx
<CatRow catKey="HR" label="Home runs" mine={11} theirs={9} status="live" leverage={.74} note="+2 · close" />
```

Always print the gap in words next to the bar — five bars at similar widths tell the reader nothing on their own.
