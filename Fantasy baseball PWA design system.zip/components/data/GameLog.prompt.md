Newest first. The stat line is a sentence a person would say, not a table of columns.

```jsx
<GameLog games={player.recentGames} />
```

A did-not-play row is dim and italic; a bad game is clay.
