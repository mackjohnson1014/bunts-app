export interface KeeperRowProps {
  rank: number;
  name: string;
  /** Team, positions, roster note. */
  meta?: string;
  score: number | string;
  /** Bar width 0-100, relative to the top-ranked player. */
  pct?: number;
  note?: string;
  /** True when the rank is inside the league's keeper slots — turns rank and bar amber. */
  inside?: boolean;
}

/**
 * Ranked keeper candidate with score, bar and one line of reasoning.
 * @startingPoint section="Data" subtitle="Ranked keeper row and cut line" viewport="700x220"
 */
export declare function KeeperRow(props: KeeperRowProps): JSX.Element;
export declare function CutLine(props: { children?: React.ReactNode }): JSX.Element;
