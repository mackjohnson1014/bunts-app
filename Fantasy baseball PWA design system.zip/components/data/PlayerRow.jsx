import React from 'react';
import { LineupLight, LineupState } from './LineupLight.jsx';
import { FormStrip } from './FormStrip.jsx';

const HITTER = ['R', 'HR', 'RBI', 'SB', 'AVG'];
const PITCHER = ['W', 'SV', 'K', 'ERA', 'WHIP'];

export const isPitcher = (p) => (p.positions || []).some((x) => x === 'SP' || x === 'RP' || x === 'P');

export const fmt = (v) => (v === undefined ? '\u2013'
  : v < 10 && !Number.isInteger(v) ? v.toFixed(3).replace(/^0/, '') : String(v));

const SUB = {
  fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-micro)', color: 'var(--chalk-dim)',
  letterSpacing: 'var(--track-tight)', minWidth: 0, overflow: 'hidden',
  textOverflow: 'ellipsis', whiteSpace: 'nowrap',
};

export function PlayerRow({ player, onOpen }) {
  const keys = isPitcher(player) ? PITCHER : HITTER;
  const Tag = onOpen ? 'button' : 'div';

  return (
    <Tag
      type={onOpen ? 'button' : undefined}
      onClick={onOpen ? () => onOpen(player) : undefined}
      style={{
        display: 'grid', gridTemplateColumns: '36px 1fr auto', gap: 'var(--space-4)',
        alignItems: 'center', padding: 'var(--row-pad-y) 2px', width: '100%',
        borderBottom: 'var(--hairline)', background: 'none', border: 0,
        borderBottomWidth: '1px', borderBottomStyle: 'solid', borderBottomColor: 'var(--rule)',
        textAlign: 'left', font: 'inherit', color: 'inherit', cursor: onOpen ? 'pointer' : undefined,
      }}
    >
      <div style={{
        fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-micro)', fontWeight: 700,
        letterSpacing: '.06em', textAlign: 'center', color: 'var(--chalk-dim)',
        background: 'var(--board-3)', borderRadius: 'var(--radius-xs)', padding: '3px 0',
      }}>{player.slot}</div>

      <div style={{ minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', flexWrap: 'wrap', gap: '2px 10px' }}>
          <div style={{ fontWeight: 600, fontSize: 'var(--text-body)' }}>{player.name}</div>
          <div style={{
            display: 'flex', flexWrap: 'wrap', justifyContent: 'flex-end', gap: '4px 10px',
            marginLeft: 'auto', textAlign: 'right', fontFamily: 'var(--font-condensed)',
            fontSize: 'var(--text-statline)', color: 'var(--chalk-dim)',
            fontVariantNumeric: 'tabular-nums', letterSpacing: '.04em',
          }}>
            {keys.filter((k) => player.seasonStats?.[k] !== undefined).map((k) => (
              <span key={k} style={{ whiteSpace: 'nowrap' }}>
                <b style={{ color: 'var(--chalk)', fontWeight: 600 }}>{fmt(player.seasonStats[k])}</b> {k}
              </span>
            ))}
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 'var(--space-3)', marginTop: '2px' }}>
          <div style={SUB}>
            {player.mlbTeam} · {(player.positions || []).join('/')}
            {player.opponent ? ' · ' + player.opponent : ''}
          </div>
          <FormStrip games={player.recentGames} />
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)', flex: 'none' }}>
        <LineupLight slot={player.slot} />
        <LineupState starting={player.startingToday} />
      </div>
    </Tag>
  );
}
