Two stacked lights: where the player sits on the roster, and whether he is in tonight's lineup.

```jsx
<LineupLight slot="SS" />
<LineupState starting={null} />
```

`starting` is `true | false | null`. Rendering null as "not starting" is the worst failure this product can have — amber em dash is the correct output.
