export interface FormGame { quality: 'good' | 'neutral' | 'bad' | 'dnp' }

export interface FormStripProps {
  /** Newest first — the strip reverses so it reads left-to-right as a trend. */
  games?: FormGame[];
}

/**
 * Five square pips: the last five games at a glance.
 * @startingPoint section="Data" subtitle="Recent form pips" viewport="700x100"
 */
export declare function FormStrip(props: FormStripProps): JSX.Element | null;
