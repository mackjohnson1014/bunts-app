import React from 'react';

const TH = {
  textAlign: 'right', fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-slate-key)',
  letterSpacing: 'var(--track-key)', textTransform: 'uppercase', color: 'var(--chalk-dim)',
  fontWeight: 600, padding: '0 0 6px',
};
const TD = { textAlign: 'right', padding: '5px 0', borderTop: 'var(--hairline)', fontSize: '14px' };

export function CompareTable({ rows = [], headers = ['Cat', 'Actual', 'Expected'] }) {
  return (
    <table style={{ width: '100%', borderCollapse: 'collapse', fontVariantNumeric: 'tabular-nums' }}>
      <thead>
        <tr>
          <th style={{ ...TH, textAlign: 'left' }}>{headers[0]}</th>
          <th style={TH}>{headers[1]}</th>
          <th style={TH}>{headers[2]}</th>
          <th style={TH} aria-label="Direction" />
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.key}>
            <td style={{ ...TD, textAlign: 'left', color: 'var(--chalk-dim)', fontFamily: 'var(--font-condensed)', letterSpacing: '.06em' }}>{r.key}</td>
            <td style={TD}>{r.actual}</td>
            <td style={{ ...TD, color: 'var(--chalk-dim)' }}>{r.expected}</td>
            <td style={TD}>
              {r.direction === 'up' ? <span style={{ color: 'var(--grass)' }}>{'\u25B2'}</span>
                : r.direction === 'down' ? <span style={{ color: 'var(--clay)' }}>{'\u25BC'}</span>
                : <span style={{ color: 'var(--chalk-dim)' }}>{'\u00b7'}</span>}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
