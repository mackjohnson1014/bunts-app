export interface GameLogEntry {
  /** Already formatted, e.g. 'Sep 12'. */
  date: string;
  opponent: string;
  /** Human line: '2-4, HR, 2 RBI' or '6.0 IP, 1 ER, 8 K'. */
  summary: string;
  quality: 'good' | 'neutral' | 'bad' | 'dnp';
}

export interface GameLogProps { games?: GameLogEntry[] }

/**
 * Last five games as three ruled columns: date, opponent, line.
 * @startingPoint section="Data" subtitle="Recent game lines" viewport="700x200"
 */
export declare function GameLog(props: GameLogProps): JSX.Element;
