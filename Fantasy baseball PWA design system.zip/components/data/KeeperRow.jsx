import React from 'react';
import { Track } from '../core/Track.jsx';

export function KeeperRow({ rank, name, meta, score, pct = 100, note, inside }) {
  return (
    <div style={{ padding: 'var(--space-5) 0', borderBottom: 'var(--hairline)' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 'var(--space-4)' }}>
        <span style={{
          fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-keep-rank)', fontWeight: 700,
          color: inside ? 'var(--amber)' : 'var(--chalk-dim)', width: '18px', fontVariantNumeric: 'tabular-nums',
        }}>{rank}</span>
        <span>
          <span style={{ fontWeight: 600, fontSize: 'var(--text-body)' }}>{name}</span>
          <div style={{
            fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-micro)',
            color: 'var(--chalk-dim)', letterSpacing: 'var(--track-tight)',
          }}>{meta}</div>
        </span>
        <span style={{
          marginLeft: 'auto', fontFamily: 'var(--font-condensed)', fontSize: '17px',
          fontWeight: 600, fontVariantNumeric: 'tabular-nums',
        }}>{score}</span>
      </div>
      <Track value={pct} color={inside ? 'var(--amber)' : 'var(--rule)'} />
      <p style={{ fontSize: 'var(--text-statline)', color: 'var(--chalk-dim)', margin: 0 }}>{note}</p>
    </div>
  );
}

export function CutLine({ children = 'Cut line' }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: '9px', margin: '14px 0 4px',
      fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-label)',
      letterSpacing: '.14em', textTransform: 'uppercase', color: 'var(--amber)',
    }}>
      <span style={{ height: '1px', background: 'var(--amber)', opacity: .45, flex: 1 }} />
      {children}
      <span style={{ height: '1px', background: 'var(--amber)', opacity: .45, flex: 1 }} />
    </div>
  );
}
