A ranked list with a visible cut line where the league's keeper slots run out.

```jsx
<KeeperRow rank={1} name="Gunnar Henderson" meta="BAL · SS/3B" score={91} pct={100} note="Top-five bat at a scarce slot." inside />
<CutLine />
```
