import type { Slot } from './LineupLight';

export interface Player {
  playerKey: string;
  name: string;
  mlbTeam: string;
  positions: string[];
  slot: Slot;
  startingToday: boolean | null;
  opponent: string | null;
  seasonStats: Record<string, number>;
  recentGames: { quality: 'good' | 'neutral' | 'bad' | 'dnp' }[];
}

export interface PlayerRowProps {
  player: Player;
  /** Pass to make the whole row a button that opens the player sheet. */
  onOpen?: (player: Player) => void;
}

/**
 * One ruled line of the lineup card: slot, name, five season stats, two lights.
 * @startingPoint section="Data" subtitle="Roster row with stats and lights" viewport="700x180"
 */
export declare function PlayerRow(props: PlayerRowProps): JSX.Element;
export declare function isPitcher(player: Player): boolean;
export declare function fmt(value: number | undefined): string;
