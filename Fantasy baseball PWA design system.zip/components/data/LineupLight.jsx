import React from 'react';

const STARTING = ['C', '1B', '2B', '3B', 'SS', 'OF', 'UTIL', 'SP', 'RP', 'P'];

export function LineupLight({ slot }) {
  const active = STARTING.includes(slot);
  const color = active ? 'var(--grass)' : 'var(--clay)';
  const label = active ? 'LU' : slot === 'BN' ? 'BN' : slot;
  return <Light color={color} label={label} />;
}

export function LineupState({ starting }) {
  const { color, label } =
    starting === true ? { color: 'var(--grass)', label: 'IN' }
    : starting === false ? { color: 'var(--clay)', label: 'OUT' }
    : { color: 'var(--amber)', label: '\u2014' };
  return <Light color={color} label={label} />;
}

function Light({ color, label }) {
  return (
    <div style={{ textAlign: 'center', width: '32px' }}>
      <div style={{ width: '7px', height: '7px', borderRadius: '50%', margin: '0 auto 3px', background: color }} />
      <div style={{
        fontFamily: 'var(--font-condensed)', fontSize: '9.5px', fontWeight: 700,
        letterSpacing: '.08em', color,
      }}>{label}</div>
    </div>
  );
}
