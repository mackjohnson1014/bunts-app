The roster's primary row. Hitters show R/HR/RBI/SB/AVG; pitchers show W/SV/K/ERA/WHIP — chosen automatically from position eligibility.

```jsx
<PlayerRow player={p} onOpen={setSelected} />
```

Rows are separated by hairlines, never boxed. Rate stats print without a leading zero (`.312`), tabular figures throughout.
