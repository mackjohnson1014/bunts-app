import React from 'react';

const COL = { fontFamily: 'var(--font-condensed)', color: 'var(--chalk-dim)', letterSpacing: 'var(--track-tight)' };

export function GameLog({ games = [] }) {
  return (
    <ul style={{ listStyle: 'none', margin: 'var(--space-3) 0 0', padding: 0 }}>
      {games.map((g) => (
        <li key={g.date} style={{
          display: 'grid', gridTemplateColumns: '52px 56px 1fr', gap: 'var(--space-3)',
          padding: '7px 0', borderBottom: 'var(--hairline)', fontSize: 'var(--text-meta)',
        }}>
          <span style={COL}>{g.date}</span>
          <span style={COL}>{g.opponent}</span>
          <span style={{
            color: g.quality === 'bad' ? 'var(--clay)' : g.quality === 'dnp' ? 'var(--chalk-dim)' : 'var(--chalk)',
            fontStyle: g.quality === 'dnp' ? 'italic' : undefined,
          }}>{g.summary}</span>
        </li>
      ))}
    </ul>
  );
}
