import React from 'react';
import { Chip } from '../core/Chip.jsx';
import { Track } from '../core/Track.jsx';

const ACCENT = { won: 'var(--grass)', lost: 'var(--clay)', live: 'var(--amber)', tied: 'var(--amber)' };

export function CatRow({ catKey, label, mine, theirs, status = 'live', leverage = 0, note }) {
  const ahead = status === 'won' || (status === 'live' && Number(mine) > Number(theirs));
  const chipTone = status === 'won' ? 'in' : status === 'lost' ? 'out' : status === 'tied' ? 'unknown' : ahead ? 'in' : 'out';
  const chipLabel = status === 'won' ? 'Won' : status === 'lost' ? 'Lost' : status === 'tied' ? 'Level' : ahead ? 'Ahead' : 'Behind';

  return (
    <div style={{
      padding: '9px 0', borderBottom: 'var(--hairline)',
      borderLeft: 'var(--border-accent) solid ' + (ACCENT[status] ?? 'transparent'),
      paddingLeft: 'var(--space-4)', marginLeft: 'calc(-1 * var(--space-4))',
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 'var(--space-3)' }}>
        <span style={{
          fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-micro)', fontWeight: 700,
          letterSpacing: '.08em', color: 'var(--chalk-dim)', minWidth: '34px',
        }}>{catKey}</span>
        <span style={{ fontSize: 'var(--text-row-title)', fontWeight: 600, flex: 1 }}>{label}</span>
        <Chip tone={chipTone}>{chipLabel}</Chip>
      </div>

      <div style={{
        display: 'flex', alignItems: 'baseline', gap: 'var(--space-3)', marginTop: '5px',
        fontFamily: 'var(--font-condensed)', fontVariantNumeric: 'tabular-nums',
      }}>
        <span style={{ fontSize: 'var(--text-cat-value)', fontWeight: 700, color: ahead ? 'var(--grass)' : 'var(--chalk)' }}>{mine}</span>
        <span style={{ fontSize: 'var(--text-label)', letterSpacing: 'var(--track-chip)', textTransform: 'uppercase', color: 'var(--chalk-dim)' }}>vs</span>
        <span style={{ fontSize: 'var(--text-cat-value)', fontWeight: 600, color: 'var(--chalk-dim)' }}>{theirs}</span>
      </div>

      {leverage > 0 ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: '9px', marginTop: '7px' }}>
          <Track value={Math.round(leverage * 100)} color="var(--amber)" style={{ flex: 1, margin: 0 }} />
          <span style={{ color: 'var(--chalk-dim)', fontSize: '11.5px', whiteSpace: 'nowrap' }}>{note}</span>
        </div>
      ) : null}
    </div>
  );
}
