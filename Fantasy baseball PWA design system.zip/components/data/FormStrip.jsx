import React from 'react';

const PIP = {
  good: { background: 'var(--grass)' },
  bad: { background: 'var(--clay)' },
  neutral: { background: 'var(--chalk-dim)', opacity: .55 },
  dnp: { background: 'transparent', border: '1px solid var(--rule)' },
};

export function FormStrip({ games = [] }) {
  if (!games.length) return null;
  return (
    <span style={{ display: 'inline-flex', gap: '3px', alignItems: 'center' }} aria-label="Recent form">
      {[...games].reverse().map((g, i) => (
        <span key={i} style={{ width: '6px', height: '6px', borderRadius: '1px', ...(PIP[g.quality] ?? PIP.neutral) }} />
      ))}
    </span>
  );
}
