export interface CompareRow {
  key: string;
  actual: string | number;
  expected: string | number;
  /** Omit or use 'flat' inside the 5% dead band. */
  direction?: 'up' | 'down' | 'flat';
}

export interface CompareTableProps {
  rows?: CompareRow[];
  /** Three column labels. Default ['Cat', 'Actual', 'Expected']. */
  headers?: [string, string, string];
}

/**
 * Bare stat table: actual against a benchmark, with a direction mark.
 * @startingPoint section="Data" subtitle="Actual vs expected stat table" viewport="700x260"
 */
export declare function CompareTable(props: CompareTableProps): JSX.Element;
