export type Slot = 'C' | '1B' | '2B' | '3B' | 'SS' | 'OF' | 'UTIL' | 'SP' | 'RP' | 'P' | 'BN' | 'IL' | 'NA';

export interface LineupLightProps {
  /** Roster slot. Starting slots read LU in grass; bench and IL read clay. */
  slot: Slot;
}

export interface LineupStateProps {
  /** THREE-state. null means "not posted", and renders amber — never as OUT. */
  starting: boolean | null;
}

/**
 * Dot-and-label status lights used on the right edge of every player row.
 * @startingPoint section="Data" subtitle="Roster slot and lineup status lights" viewport="700x130"
 */
export declare function LineupLight(props: LineupLightProps): JSX.Element;
export declare function LineupState(props: LineupStateProps): JSX.Element;
