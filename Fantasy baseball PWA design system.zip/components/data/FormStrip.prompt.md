Five 6px squares, oldest on the left.

```jsx
<FormStrip games={player.recentGames} />
```

An empty list renders nothing rather than five empty boxes.
