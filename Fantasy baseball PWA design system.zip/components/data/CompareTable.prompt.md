Used in the player sheet to compare the last fourteen days against the player's own season rate.

```jsx
<CompareTable rows={[{ key: 'HR', actual: 4, expected: 2.6, direction: 'up' }]} />
```

No zebra striping, no vertical rules — hairlines between rows only. A direction mark needs a 5% margin, otherwise every row gets an arrow and the arrows stop meaning anything.
