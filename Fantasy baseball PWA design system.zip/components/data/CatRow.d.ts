export interface CatRowProps {
  /** Category abbreviation, e.g. 'HR', 'ERA'. */
  catKey: string;
  /** Full name, e.g. 'Home runs'. */
  label: string;
  mine: string | number;
  theirs: string | number;
  status?: 'live' | 'tied' | 'won' | 'lost';
  /** 0-1. How reachable the gap is; drives the bar width. 0 hides the bar. */
  leverage?: number;
  /** Gap plus closeness, e.g. '+3 · close'. */
  note?: string;
}

/**
 * One head-to-head category: mine vs theirs, with a leverage bar.
 * @startingPoint section="Data" subtitle="Head-to-head category row" viewport="700x190"
 */
export declare function CatRow(props: CatRowProps): JSX.Element;
