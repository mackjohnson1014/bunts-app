import React from 'react';
import { Icon } from './Icon.jsx';

export function SetList({ children }) {
  return (
    <div style={{
      border: '1px solid var(--rule)', borderRadius: 'var(--radius-lg)',
      overflow: 'hidden', background: 'var(--board-2)',
    }}>{children}</div>
  );
}

export function SetRow({ icon, label, value, onClick, last }) {
  return (
    <button type="button" onClick={onClick} style={{
      width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      gap: 'var(--space-4)', padding: '15px 14px', border: 0,
      borderBottom: last ? 0 : '1px solid var(--rule)', background: 'none',
      textAlign: 'left', font: 'inherit', color: 'inherit', cursor: 'pointer',
    }}>
      <span style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-5)', minWidth: 0 }}>
        {icon ? <Icon name={icon} size={20} style={{ color: 'var(--chalk-dim)' }} /> : null}
        <span style={{ fontSize: 'var(--text-body)', fontWeight: 600 }}>{label}</span>
      </span>
      <span style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)', color: 'var(--chalk-dim)' }}>
        {value ? <span style={{ fontSize: 'var(--text-meta)' }}>{value}</span> : null}
        <span aria-hidden="true" style={{ fontSize: '18px', lineHeight: 1 }}>{'\u203a'}</span>
      </span>
    </button>
  );
}
