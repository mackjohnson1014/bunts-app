```jsx
<ScreenHeader title="Today" subtitle="Lineups lock at 7:05 PM · 42 min" updated="4m ago" onReload={reload} />
```

The subtitle carries the single most time-sensitive fact on the screen. The refresh control is the only spinner in the product.
