import React from 'react';

export function ScreenHeader({ title, subtitle, sample, updated, onBack, onReload, loading }) {
  return (
    <div style={{ padding: '8px 0 14px', borderBottom: 'var(--hairline)', marginBottom: 'var(--space-7)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)', flexWrap: 'wrap' }}>
        {onBack ? (
          <button type="button" onClick={onBack} aria-label="Back" style={{
            background: 'none', border: 0, cursor: 'pointer', padding: '4px 8px 4px 0', marginLeft: '-4px',
            color: 'var(--amber)', fontSize: 'var(--text-body)', fontWeight: 600,
            display: 'flex', alignItems: 'center',
          }}>
            <span aria-hidden="true" style={{ fontSize: '20px', lineHeight: 1, marginRight: '1px' }}>{'\u2039'}</span>Back
          </button>
        ) : null}

        <h1 style={{
          fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-screen-title)', fontWeight: 700,
          lineHeight: 1, margin: 0, textTransform: 'uppercase', letterSpacing: 'var(--track-title)',
        }}>{title}</h1>

        {sample ? (
          <span style={{
            fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-chip)', fontWeight: 700,
            letterSpacing: 'var(--track-chip)', textTransform: 'uppercase', color: 'var(--amber)',
            border: '1px solid var(--amber)', borderRadius: 'var(--radius-chip)', padding: '1px 6px',
          }}>Sample data</span>
        ) : null}

        {onReload ? (
          <button type="button" onClick={onReload} disabled={loading} aria-label="Refresh" style={{
            marginLeft: 'auto', flex: 'none', width: '34px', height: '34px', borderRadius: '50%',
            background: 'var(--board-3)', border: '1px solid var(--rule)', color: 'var(--chalk-dim)',
            fontSize: '17px', lineHeight: 1, cursor: 'pointer', display: 'grid', placeItems: 'center',
            opacity: loading ? .5 : 1,
            animation: loading ? 'bunts-spin var(--dur-spin) linear infinite' : undefined,
          }}>{'\u21bb'}</button>
        ) : null}
      </div>

      {subtitle ? <p style={{ margin: '6px 0 0', fontSize: 'var(--text-meta)', color: 'var(--chalk-dim)' }}>{subtitle}</p> : null}
      {updated ? (
        <p style={{
          margin: '6px 0 0', fontFamily: 'var(--font-condensed)', fontSize: '11.5px',
          letterSpacing: '.08em', textTransform: 'uppercase', color: 'var(--chalk-dim)',
        }}>Updated {updated}</p>
      ) : null}
    </div>
  );
}
