The whole icon inventory — seven glyphs, one per section, plus the ball mark. There is no icon library in this product; if a new glyph is needed, draw it on the same 20x20 grid at 1.4-1.7 stroke with round caps.

```jsx
<Icon name="roster" size={19} />
<Logo size={96} />
```

Colour comes from `currentColor`, so the wrapping element decides. No emoji anywhere in the product.
