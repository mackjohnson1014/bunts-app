Fixed to the bottom of the app column, outside the scrolling screen.

```jsx
<TabBar value={tab} onChange={setTab} />
```

Six is the ceiling. Sections beyond six live on the Home tile grid instead — Transactions is the precedent.
