export interface HomeTileProps {
  icon: string;
  label: string;
  onClick?: () => void;
}

/**
 * Home-screen-style launcher tile: amber glyph on a raised rounded square.
 * @startingPoint section="Navigation" subtitle="Launcher tiles" viewport="700x220"
 */
export declare function HomeTile(props: HomeTileProps): JSX.Element;
export declare function HomeGrid(props: { children?: React.ReactNode }): JSX.Element;
