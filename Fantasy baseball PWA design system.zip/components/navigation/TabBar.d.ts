export interface TabItem { id: string; label: string; icon: string }

export interface TabBarProps {
  /** Six items max — the dock does not grow when a section is added. */
  tabs?: TabItem[];
  value?: string;
  onChange?: (id: string) => void;
}

/**
 * Six-slot bottom dock. Selected tab turns amber and grows a 2px top rule.
 * @startingPoint section="Navigation" subtitle="Bottom tab bar" viewport="700x120"
 */
export declare function TabBar(props: TabBarProps): JSX.Element;
export declare const DEFAULT_TABS: TabItem[];
