export interface SetRowProps {
  /** Icon name from the app's glyph set. */
  icon?: string;
  label: string;
  /** Optional right-aligned current value. */
  value?: string;
  onClick?: () => void;
  last?: boolean;
}

/**
 * Grouped settings list: a boxed stack of chevron rows.
 * @startingPoint section="Navigation" subtitle="Settings list rows" viewport="700x220"
 */
export declare function SetList(props: { children?: React.ReactNode }): JSX.Element;
export declare function SetRow(props: SetRowProps): JSX.Element;
