import React from 'react';
import { Icon } from './Icon.jsx';

export const DEFAULT_TABS = [
  { id: 'home', label: 'Home', icon: 'home' },
  { id: 'today', label: 'Today', icon: 'today' },
  { id: 'week', label: 'Week', icon: 'week' },
  { id: 'roster', label: 'Roster', icon: 'roster' },
  { id: 'keepers', label: 'Keepers', icon: 'keepers' },
  { id: 'settings', label: 'Settings', icon: 'settings' },
];

export function TabBar({ tabs = DEFAULT_TABS, value, onChange }) {
  return (
    <nav role="tablist" aria-label="Screens" style={{
      display: 'grid', gridTemplateColumns: 'repeat(' + tabs.length + ', 1fr)',
      borderTop: '1px solid var(--rule)', background: 'var(--board-2)', flex: 'none',
    }}>
      {tabs.map((t) => {
        const selected = t.id === value;
        return (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={selected}
            onClick={() => onChange && onChange(t.id)}
            style={{
              appearance: 'none', background: 'none', border: 0, cursor: 'pointer',
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
              gap: '3px', padding: '9px 2px 8px',
              color: selected ? 'var(--amber)' : 'var(--chalk-dim)',
              borderTop: 'var(--border-tab-active) solid ' + (selected ? 'var(--amber)' : 'transparent'),
              marginTop: '-1px', minHeight: 'var(--tabbar-h)',
            }}
          >
            <Icon name={t.icon} size={19} />
            <span style={{
              fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-tab)', fontWeight: 600,
              letterSpacing: 'var(--track-tight)', textTransform: 'uppercase',
            }}>{t.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
