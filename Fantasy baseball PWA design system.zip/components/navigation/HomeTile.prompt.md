The front door: three tiles per row, one per section.

```jsx
<HomeGrid>
  <HomeTile icon="today" label="Today" onClick={() => go('today')} />
  <HomeTile icon="week" label="This Week" onClick={() => go('week')} />
</HomeGrid>
```

16px radius, the largest in the system, and the only place a glyph sits on a filled square.
