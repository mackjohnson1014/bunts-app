```jsx
<SetList>
  <SetRow icon="settings" label="Notifications" onClick={open} />
  <SetRow icon="roster" label="Your profile" value="Mack" onClick={open} last />
</SetList>
```

Tapping a row slides a detail pane in from the right; the pane's header carries the amber Back link.
