import React from 'react';
import { Icon } from './Icon.jsx';

export function HomeTile({ icon, label, onClick }) {
  return (
    <button type="button" onClick={onClick} style={{
      appearance: 'none', background: 'none', border: 0, cursor: 'pointer', padding: 0,
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      gap: 'var(--space-3)', color: 'var(--chalk)',
    }}>
      <span style={{
        width: '60px', height: '60px', borderRadius: 'var(--radius-tile)',
        background: 'var(--board-3)', border: '1px solid var(--rule)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name={icon} size={27} style={{ color: 'var(--amber)' }} />
      </span>
      <span style={{
        fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-statline)', fontWeight: 600,
        letterSpacing: '.04em', textAlign: 'center',
      }}>{label}</span>
    </button>
  );
}

export function HomeGrid({ children }) {
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 'var(--space-9) var(--space-5)', paddingTop: 'var(--space-2)',
    }}>{children}</div>
  );
}
