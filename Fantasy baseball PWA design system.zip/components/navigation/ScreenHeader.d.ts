export interface ScreenHeaderProps {
  /** Rendered condensed, uppercase, 32px. */
  title: string;
  subtitle?: React.ReactNode;
  /** Shows the amber "Sample data" tag. */
  sample?: boolean;
  /** Relative time string, e.g. '4m ago'. */
  updated?: string;
  onBack?: () => void;
  onReload?: () => void;
  /** Spins the refresh button and disables it. */
  loading?: boolean;
}

/**
 * Every screen starts here: big condensed title, one line of context, a rule.
 * @startingPoint section="Navigation" subtitle="Screen header" viewport="700x180"
 */
export declare function ScreenHeader(props: ScreenHeaderProps): JSX.Element;
