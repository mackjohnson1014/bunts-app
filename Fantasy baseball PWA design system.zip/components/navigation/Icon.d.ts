export type IconName = 'home' | 'today' | 'week' | 'roster' | 'keepers' | 'transactions' | 'settings';

export interface IconProps {
  name: IconName;
  /** px. 19 in the tab bar, 20 in settings rows, 27 on a home tile. */
  size?: number;
  style?: React.CSSProperties;
}

export interface LogoProps {
  /** px. The mark is a baseball: chalk leather, clay seams. */
  size?: number;
  style?: React.CSSProperties;
}

/**
 * The app's seven hand-drawn glyphs and the ball mark.
 * @startingPoint section="Brand" subtitle="Icon set and app mark" viewport="700x160"
 */
export declare function Icon(props: IconProps): JSX.Element;
export declare function Logo(props: LogoProps): JSX.Element;
export declare const ICON_NAMES: IconName[];
