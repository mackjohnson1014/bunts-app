import React from 'react';

const FIELD = {
  width: '100%', maxWidth: '100%', padding: 'var(--space-4)',
  background: 'var(--board-2)', color: 'var(--chalk)',
  border: '1px solid var(--rule)', borderRadius: 'var(--radius-md)',
  fontFamily: 'var(--font-body)', fontSize: 'var(--text-input)', resize: 'vertical',
};

export function NoteInput({ multiline = true, style, ...rest }) {
  const Tag = multiline ? 'textarea' : 'input';
  return <Tag style={{ ...FIELD, ...(multiline ? {} : { resize: undefined }), ...style }} {...rest} />;
}

export function Field({ label, children }) {
  return (
    <label style={{ display: 'block', minWidth: 0 }}>
      <span style={{
        display: 'block', fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-chip)',
        letterSpacing: 'var(--track-key)', textTransform: 'uppercase',
        color: 'var(--chalk-dim)', marginBottom: 'var(--space-1)',
      }}>{label}</span>
      {children}
    </label>
  );
}
