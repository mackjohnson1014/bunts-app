```jsx
<Field label="First name"><NoteInput multiline={false} value={name} onChange={onChange} /></Field>
<NoteInput rows={2} maxLength={280} placeholder="Why Gunnar? (optional)" />
```

Font size is locked at 16px. Anything smaller makes iOS Safari zoom the whole page on focus, which reads as a broken layout rather than a zoom.
