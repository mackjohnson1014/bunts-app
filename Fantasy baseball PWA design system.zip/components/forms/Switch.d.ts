export interface SwitchProps {
  checked: boolean;
  onChange?: (next: boolean) => void;
  'aria-label'?: string;
}

export interface ToggleRowProps {
  title: string;
  description?: string;
  checked: boolean;
  onChange?: (next: boolean) => void;
  /** Drops the divider on the last row of a group. */
  last?: boolean;
}

/**
 * Amber-on-dark switch, and the labelled row it lives in.
 * @startingPoint section="Forms" subtitle="Switch and labelled toggle row" viewport="700x200"
 */
export declare function Switch(props: SwitchProps): JSX.Element;
export declare function ToggleRow(props: ToggleRowProps): JSX.Element;
