import React from 'react';

export function Switch({ checked, onChange, 'aria-label': ariaLabel }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-pressed={checked}
      aria-label={ariaLabel}
      onClick={() => onChange && onChange(!checked)}
      style={{
        appearance: 'none', width: '46px', height: '27px', borderRadius: 'var(--radius-pill)',
        flex: 'none', position: 'relative', cursor: 'pointer', padding: 0,
        background: checked ? 'var(--accent-soft)' : 'var(--board-3)',
        border: '1px solid ' + (checked ? 'var(--amber)' : 'var(--rule)'),
        transition: 'background var(--dur-fast) ease, border-color var(--dur-fast) ease',
      }}
    >
      <span style={{
        position: 'absolute', top: '2px', left: '2px', width: '21px', height: '21px',
        borderRadius: '50%', background: checked ? 'var(--amber)' : 'var(--chalk-dim)',
        transform: checked ? 'translateX(19px)' : 'none',
        transition: 'transform var(--dur-fast) ease, background var(--dur-fast) ease',
      }} />
    </button>
  );
}

export function ToggleRow({ title, description, checked, onChange, last }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 'var(--space-5)',
      padding: '13px 0', borderBottom: last ? 0 : '1px solid var(--rule)',
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 'var(--text-row-title)', fontWeight: 600 }}>{title}</div>
        {description ? <div style={{ fontSize: 'var(--text-statline)', color: 'var(--chalk-dim)', marginTop: '2px' }}>{description}</div> : null}
      </div>
      <Switch checked={checked} onChange={onChange} aria-label={title} />
    </div>
  );
}
