Every notification preference in Settings is a ToggleRow.

```jsx
<ToggleRow title="Scratched from the lineup" description="When an active player is out tonight." checked={on} onChange={setOn} />
```

On is amber: amber knob on a 25%-amber track. Off is a dim knob on the raised surface.
