import React from 'react';

export function SegmentedControl({ options = [], value, onChange, 'aria-label': ariaLabel }) {
  return (
    <div role="radiogroup" aria-label={ariaLabel} style={{
      display: 'grid', gridAutoFlow: 'column', gap: '2px', background: 'var(--board-3)',
      borderRadius: 'var(--radius-md)', padding: '2px', marginBottom: 'var(--space-2)',
    }}>
      {options.map((o) => {
        const selected = o.id === value;
        return (
          <button
            key={o.id}
            type="button"
            role="radio"
            aria-checked={selected}
            onClick={() => onChange && onChange(o.id)}
            style={{
              background: selected ? 'var(--board)' : 'none', border: 0, cursor: 'pointer',
              borderRadius: 'var(--radius-sm)', padding: '6px 4px',
              fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-micro)', fontWeight: 600,
              letterSpacing: '.08em', textTransform: 'uppercase',
              color: selected ? 'var(--amber)' : 'var(--chalk-dim)',
            }}
          >{o.label}</button>
        );
      })}
    </div>
  );
}
