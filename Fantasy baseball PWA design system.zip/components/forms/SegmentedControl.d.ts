export interface SegmentOption { id: string; label: string }

export interface SegmentedControlProps {
  options?: SegmentOption[];
  value?: string;
  onChange?: (id: string) => void;
  'aria-label'?: string;
}

/**
 * Two to four mutually exclusive choices in one inset strip.
 * @startingPoint section="Forms" subtitle="Segmented control" viewport="700x120"
 */
export declare function SegmentedControl(props: SegmentedControlProps): JSX.Element;
