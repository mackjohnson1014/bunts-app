export interface NoteInputProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  /** Textarea by default; false renders a single-line input. */
  multiline?: boolean;
}

export interface FieldProps {
  /** Condensed uppercase label rendered above the control. */
  label: string;
  children?: React.ReactNode;
}

/**
 * Text entry on the dark board, and the tracked label that sits above it.
 * @startingPoint section="Forms" subtitle="Text field and labelled field" viewport="700x220"
 */
export declare function NoteInput(props: NoteInputProps): JSX.Element;
export declare function Field(props: FieldProps): JSX.Element;
