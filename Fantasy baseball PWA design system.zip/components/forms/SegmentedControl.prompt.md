Used to pick the kind of call you are sending a co-owner.

```jsx
<SegmentedControl
  aria-label="Recommendation"
  value={rec}
  onChange={setRec}
  options={[{ id: 'start', label: 'Start him' }, { id: 'sit', label: 'Sit him' }, { id: 'watch', label: 'Keep an eye' }]}
/>
```

The selected segment goes darker than the track, not lighter, and its label turns amber.
