export interface TrackProps {
  /** 0-100. */
  value?: number;
  /** Fill colour token. Amber when the row is "in", rule when it is not. */
  color?: string;
  style?: React.CSSProperties;
}

/**
 * 3px progress rule — keeper score, category leverage, weekly add cap.
 * @startingPoint section="Core" subtitle="3px progress rule" viewport="700x110"
 */
export declare function Track(props: TrackProps): JSX.Element;
