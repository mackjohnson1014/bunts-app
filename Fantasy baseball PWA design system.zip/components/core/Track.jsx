import React from 'react';

export function Track({ value = 0, color = 'var(--rule)', style }) {
  return (
    <div style={{
      height: '3px', background: 'var(--board-3)', borderRadius: '2px',
      overflow: 'hidden', margin: '9px 0 6px', ...style,
    }}>
      <div style={{ height: '3px', width: Math.max(0, Math.min(100, value)) + '%', background: color }} />
    </div>
  );
}
