export interface SectionLabelProps {
  /** Drops the top margin for the first label on a screen. */
  first?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * Condensed, tracked, uppercase section heading — the app's only subhead.
 * @startingPoint section="Core" subtitle="Section heading" viewport="700x100"
 */
export declare function SectionLabel(props: SectionLabelProps): JSX.Element;
