A hairline bar. Always paired with the number it represents; the bar alone is never the information.

```jsx
<Track value={72} color="var(--amber)" />
```
