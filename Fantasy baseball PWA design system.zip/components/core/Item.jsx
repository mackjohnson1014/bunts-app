import React from 'react';

const ACCENT = { critical: 'var(--clay)', pending: 'var(--amber)', ok: 'var(--grass)', plain: 'var(--rule)' };

export function Item({ tone = 'plain', unread, as = 'div', children, style, ...rest }) {
  const Tag = as === 'button' ? 'button' : 'div';
  return (
    <Tag
      type={Tag === 'button' ? 'button' : undefined}
      style={{
        display: 'block', width: '100%', textAlign: 'left', font: 'inherit', color: 'inherit',
        border: '1px solid var(--rule)', borderLeftWidth: 'var(--border-accent)',
        borderLeftColor: ACCENT[tone] ?? ACCENT.plain,
        borderRadius: 'var(--radius-md)', background: 'var(--board-2)',
        padding: 'var(--item-pad)', marginBottom: 'var(--space-3)',
        boxShadow: unread ? 'var(--shadow-unread)' : undefined,
        cursor: Tag === 'button' ? 'pointer' : undefined,
        ...style,
      }}
      {...rest}
    >{children}</Tag>
  );
}

export function ItemTop({ children }) {
  return <div style={{ display: 'flex', alignItems: 'baseline', gap: 'var(--space-3)' }}>{children}</div>;
}

export function ItemName({ children }) {
  return <span style={{ fontWeight: 600, fontSize: 'var(--text-body)' }}>{children}</span>;
}

export function ItemMeta({ children }) {
  return (
    <span style={{
      fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-meta)', color: 'var(--chalk-dim)',
      letterSpacing: 'var(--track-tight)', marginLeft: 'auto', whiteSpace: 'nowrap',
    }}>{children}</span>
  );
}

export function ItemVerdict({ children, style }) {
  return <p style={{ margin: '5px 0 0', fontSize: 'var(--text-verdict)', ...style }}>{children}</p>;
}

export function ItemFix({ children }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: '7px', marginTop: '9px', paddingTop: '9px',
      borderTop: 'var(--hairline-dashed)', fontSize: 'var(--text-meta)',
    }}>{children}</div>
  );
}
