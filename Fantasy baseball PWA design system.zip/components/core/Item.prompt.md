The one card in the system: a ruled box whose left edge carries the status colour. Everything actionable is an Item.

```jsx
<Item tone="critical" as="button" onClick={open}>
  <ItemTop>
    <ItemName>Bobby Witt Jr.</ItemName>
    <Chip tone="out">Sit</Chip>
    <ItemMeta>SS · @ CLE</ItemMeta>
  </ItemTop>
  <ItemVerdict>Not in tonight's lineup.</ItemVerdict>
  <ItemFix><LineupState starting={false} /><span>82%</span></ItemFix>
</Item>
```

The left rule is the only place colour fills anything. `ItemFix` adds the dashed divider used for the "what to do about it" line.
