import React from 'react';

const BASE = {
  display: 'block', width: '100%', border: 0,
  borderRadius: 'var(--radius-lg)', padding: '13px',
  fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-btn)',
  fontWeight: 700, letterSpacing: 'var(--track-btn)', textTransform: 'uppercase',
  cursor: 'pointer', lineHeight: 1.2,
};

export function Button({ variant = 'primary', disabled, children, style, ...rest }) {
  const tone =
    disabled ? { background: 'var(--board-3)', color: 'var(--chalk-dim)', border: '1px solid var(--rule)', cursor: 'default' }
    : variant === 'ghost' ? { background: 'none', border: '1px solid var(--rule)', color: 'var(--chalk)' }
    : { background: 'var(--amber)', color: 'var(--ink)' };

  return (
    <button type="button" disabled={disabled} style={{ ...BASE, ...tone, ...style }} {...rest}>
      {children}
    </button>
  );
}
