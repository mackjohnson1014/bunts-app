Groups a list of rows or items under a quiet label. There is no second level of heading below a screen title.

```jsx
<SectionLabel first>Needs a decision</SectionLabel>
```

Sentence case, not title case: "Check back before lock", "From your co-owner".
