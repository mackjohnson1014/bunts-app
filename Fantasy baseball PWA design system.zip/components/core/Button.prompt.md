Full-width uppercase action button — the app's only button shape; one amber primary per screen at most.

```jsx
<Button onClick={send}>Send suggestion</Button>
<Button variant="ghost" onClick={retry}>Try again</Button>
```

Variants: `primary` (amber on ink), `ghost` (ruled outline), `disabled` (raised surface, dim chalk, no pointer). Always block-level and full width — buttons never sit inline except in a footer row, where the ghost shrinks to its content.
