export interface ItemProps {
  /** Left rule colour: critical = clay, pending = amber, ok = grass, plain = rule. */
  tone?: 'critical' | 'pending' | 'ok' | 'plain';
  /** Adds the inset amber bar used for an unread co-owner suggestion. */
  unread?: boolean;
  /** Render as a button when the whole card opens something. */
  as?: 'div' | 'button';
  onClick?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * The app's card: a ruled box with a 3px status rule down the left edge.
 * @startingPoint section="Core" subtitle="Status card with left rule" viewport="700x260"
 */
export declare function Item(props: ItemProps): JSX.Element;
export declare function ItemTop(props: { children?: React.ReactNode }): JSX.Element;
export declare function ItemName(props: { children?: React.ReactNode }): JSX.Element;
export declare function ItemMeta(props: { children?: React.ReactNode }): JSX.Element;
export declare function ItemVerdict(props: { children?: React.ReactNode; style?: React.CSSProperties }): JSX.Element;
export declare function ItemFix(props: { children?: React.ReactNode }): JSX.Element;
