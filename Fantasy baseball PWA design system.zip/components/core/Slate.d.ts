export interface SlateProps { children?: React.ReactNode; style?: React.CSSProperties }

export interface SlateCellProps {
  value: React.ReactNode;
  label: string;
  /** Token colour for the number, e.g. 'var(--grass)'. Omit for chalk. */
  color?: string;
  /** Set on the final cell to drop its divider. */
  last?: boolean;
}

/**
 * The count strip at the top of a screen — a boxed row of big numbers.
 * @startingPoint section="Core" subtitle="Count strip" viewport="700x140"
 */
export declare function Slate(props: SlateProps): JSX.Element;
export declare function SlateCell(props: SlateCellProps): JSX.Element;
