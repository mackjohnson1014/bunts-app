Shown instead of a screen's body while the first fetch is in flight.

```jsx
{loading ? <Skeleton cards={4} /> : children}
```

Never a spinner in the body — a spinner only ever appears on the header refresh button.
