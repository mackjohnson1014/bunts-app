import React from 'react';

const LINE = {
  height: '9px', borderRadius: 'var(--radius-chip)', marginBottom: 'var(--space-3)',
  background: 'linear-gradient(90deg, var(--board-3) 25%, var(--rule) 50%, var(--board-3) 75%)',
  backgroundSize: '200% 100%',
  animation: 'bunts-shimmer var(--dur-shimmer) linear infinite',
};

export function Skeleton({ cards = 4 }) {
  return (
    <div aria-hidden="true">
      {Array.from({ length: cards }, (_, i) => (
        <div key={i} style={{
          border: '1px solid var(--rule)', borderRadius: 'var(--radius-md)',
          background: 'var(--board-2)', padding: 'var(--card-pad)', marginBottom: 'var(--space-3)',
        }}>
          <div style={{ ...LINE, width: '55%' }} />
          <div style={{ ...LINE, width: '80%' }} />
          <div style={{ ...LINE, width: '35%', marginBottom: 0 }} />
        </div>
      ))}
    </div>
  );
}
