Four numbers that summarise the screen, in a ruled strip under the header.

```jsx
<Slate>
  <SlateCell value={9} label="Active" />
  <SlateCell value={6} label="In" color="var(--grass)" />
  <SlateCell value={1} label="Out" color="var(--clay)" />
  <SlateCell value={2} label="Unposted" color="var(--amber)" last />
</Slate>
```

Three or four cells. Colour the number, never the cell.
