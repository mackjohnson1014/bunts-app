import React from 'react';

export function Slate({ children, style }) {
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: 'repeat(' + React.Children.count(children) + ', 1fr)',
      border: '1px solid var(--rule)', borderRadius: 'var(--radius-lg)',
      overflow: 'hidden', marginBottom: 'var(--space-8)', ...style,
    }}>{children}</div>
  );
}

export function SlateCell({ value, label, color, last }) {
  return (
    <div style={{ padding: '10px 4px', textAlign: 'center', borderRight: last ? 0 : '1px solid var(--rule)' }}>
      <span style={{
        display: 'block', fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-slate-number)',
        fontWeight: 700, lineHeight: 1, fontVariantNumeric: 'tabular-nums', color,
      }}>{value}</span>
      <span style={{
        display: 'block', fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-slate-key)',
        letterSpacing: 'var(--track-key)', textTransform: 'uppercase',
        color: 'var(--chalk-dim)', marginTop: 'var(--space-1)',
      }}>{label}</span>
    </div>
  );
}
