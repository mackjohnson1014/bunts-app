export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** primary = amber fill, ghost = ruled outline. */
  variant?: 'primary' | 'ghost';
  disabled?: boolean;
  children?: React.ReactNode;
}

/**
 * Full-width action button. Amber fill for the one real action on a screen.
 * @startingPoint section="Core" subtitle="Primary, ghost and disabled" viewport="700x150"
 */
export declare function Button(props: ButtonProps): JSX.Element;
