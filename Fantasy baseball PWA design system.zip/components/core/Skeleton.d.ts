export interface SkeletonProps {
  /** How many placeholder cards to draw. Default 4. */
  cards?: number;
}

/**
 * Loading placeholder shaped like the content it replaces, so nothing jumps.
 * @startingPoint section="Core" subtitle="Loading placeholder" viewport="700x200"
 */
export declare function Skeleton(props: SkeletonProps): JSX.Element;
