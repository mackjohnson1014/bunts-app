A one- or two-word outlined status label that sits beside a player name.

```jsx
<Chip tone="out">Sit</Chip>
<Chip tone="unknown">DTD</Chip>
```

Never filled — the border is the chip. `unknown` is amber and means "not determined", which is a different statement from `out`; do not collapse the two.
