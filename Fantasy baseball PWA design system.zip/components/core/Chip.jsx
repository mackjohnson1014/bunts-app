import React from 'react';

const TONE = { in: 'var(--grass)', out: 'var(--clay)', unknown: 'var(--amber)', neutral: 'var(--chalk-dim)' };

export function Chip({ tone = 'neutral', children }) {
  return (
    <span style={{
      color: TONE[tone] ?? TONE.neutral,
      fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-chip)',
      fontWeight: 600, letterSpacing: 'var(--track-chip)', textTransform: 'uppercase',
      border: '1px solid currentColor', borderRadius: 'var(--radius-chip)',
      padding: '1px 5px', lineHeight: 1.4, whiteSpace: 'nowrap',
    }}>{children}</span>
  );
}
