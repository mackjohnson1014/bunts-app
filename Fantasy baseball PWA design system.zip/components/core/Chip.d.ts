export interface ChipProps {
  /** in = good/start/add, out = bad/sit/drop, unknown = DTD/wait/level. */
  tone?: 'in' | 'out' | 'unknown' | 'neutral';
  children?: React.ReactNode;
}

/**
 * Tiny outlined status label — colour carried by the border and the text together.
 * @startingPoint section="Core" subtitle="Status chip, four tones" viewport="700x120"
 */
export declare function Chip(props: ChipProps): JSX.Element;
