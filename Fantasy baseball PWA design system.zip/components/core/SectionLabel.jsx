import React from 'react';

export function SectionLabel({ children, first, style }) {
  return (
    <p style={{
      fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-label)', fontWeight: 600,
      letterSpacing: 'var(--track-sect)', textTransform: 'uppercase', color: 'var(--chalk-dim)',
      margin: first ? '0 0 var(--space-3)' : 'var(--space-9) 0 var(--space-3)',
      ...style,
    }}>{children}</p>
  );
}
