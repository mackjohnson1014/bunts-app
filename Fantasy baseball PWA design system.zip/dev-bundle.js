/* Development shim. The design-system compiler generates _ds_bundle.js and
   exposes the components on a global namespace; until that file exists (a fresh
   project, or a local preview), this reads the component sources, strips their
   module syntax and evaluates them into window.Bunts so the cards and the UI kit
   still render. It does nothing once the real bundle is present. */
(function () {
  if (window.Bunts || window.BuntsDesignSystem) return;

  var ROOT = (document.currentScript && document.currentScript.src || '').replace(/dev-bundle\.js.*$/, '');

  /* Prefer the compiled bundle when the project has been built. */
  try {
    var probe = new XMLHttpRequest();
    probe.open('GET', ROOT + '_ds_bundle.js', false);
    probe.send(null);
    if (probe.status >= 200 && probe.status < 300 && probe.responseText) {
      (new Function(probe.responseText))();
      if (window.Bunts || window.BuntsDesignSystem) return;
    }
  } catch (e) { /* not built yet — fall through to the source shim below */ }

  /* Dependency order: a file may use anything declared in the files above it. */
  var FILES = [
    'core/Button', 'core/Chip', 'core/Item', 'core/SectionLabel', 'core/Slate',
    'core/Skeleton', 'core/Track',
    'navigation/Icon',
    'data/FormStrip', 'data/LineupLight', 'data/PlayerRow', 'data/CatRow',
    'data/KeeperRow', 'data/CompareTable', 'data/GameLog',
    'forms/Switch', 'forms/SegmentedControl', 'forms/NoteInput',
    'navigation/TabBar', 'navigation/HomeTile', 'navigation/ScreenHeader', 'navigation/SetRow',
    'feedback/Sheet', 'feedback/Banner', 'feedback/Stack'
  ];

  function read(url) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, false);
    xhr.send(null);
    return xhr.responseText;
  }

  var ns = {};

  FILES.forEach(function (file) {
    var src = read(ROOT + 'components/' + file + '.jsx')
      .replace(/^\s*import[^;]+;\s*$/gm, '');

    /* Names this file exports. */
    var exported = [];
    src.replace(/^export\s+(?:function|const)\s+([A-Za-z0-9_]+)/gm, function (m, n) {
      exported.push(n);
      return m;
    });
    src = src.replace(/^export\s+/gm, '');

    /* Anything declared anywhere in this file must not be shadowed by an inject. */
    var declared = [];
    src.replace(/^(?:function|const|var|let)\s+([A-Za-z0-9_]+)/gm, function (m, n) {
      declared.push(n);
      return m;
    });

    var inject = Object.keys(ns).filter(function (k) { return declared.indexOf(k) < 0; });
    var head = inject.map(function (k) { return 'var ' + k + ' = __ns[' + JSON.stringify(k) + '];'; }).join('');
    var tail = 'return {' + exported.map(function (n) { return JSON.stringify(n) + ':' + n; }).join(',') + '};';

    var code = Babel.transform('(function (React, __ns) {' + head + src + tail + '})', { presets: [['react', { runtime: 'classic' }]] }).code;
    var mod;
    try {
      mod = eval(code)(window.React, ns);
    } catch (e) {
      console.error('dev-bundle: failed on ' + file, e);
      return;
    }
    Object.keys(mod).forEach(function (k) { ns[k] = mod[k]; });
  });

  window.Bunts = ns;
})();
