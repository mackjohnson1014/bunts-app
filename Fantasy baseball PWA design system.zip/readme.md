# Bunts — design system

Bunts is a personal fantasy-baseball companion PWA for one Yahoo Fantasy
Baseball team in the "Unruly Bunts" keeper league. Single user, single league,
head-to-head categories. It is read-only against the Yahoo Fantasy Sports API:
the app tells you what to do, and you apply the change by hand in Yahoo,
because read-only is the only access Yahoo grants.

The product's whole reason to exist is a decision under time pressure — *is
this player actually in tonight's lineup, and does the category it moves still
matter this week?* Every screen answers a version of that question, and the
visual system is built to make an unknown look different from a no.

## Sources

Everything here is lifted from the app's own code, not invented:

- Repository: **https://github.com/mackjohnson1014/bunts-app** (branch `main`)
- The installed PWA: `web/` — `web/src/styles.css` (the palette and every
  component's real numbers), `web/src/components.tsx`, `web/src/screens/*`,
  `web/src/PlayerSheet.tsx`, `web/src/icons.tsx`, `web/src/Logo.tsx`,
  `web/make-icons.py`, `web/index.html`
- Domain model: `web/src/types.ts`, `web/src/scoring/categories.ts`
- Product rules: `CLAUDE.md`, `README.md`
- A React Native build exists at `mobile/` and is much less complete than the
  web app. The web PWA is the ground truth for this system.

`github.md` records the association and maps each surface here back to the
files it came from.

## Surfaces

One product, one surface: an installed phone-width PWA. Six sections in a
bottom dock (Home, Today, This Week, Roster, Keepers, Settings) plus
Transactions, which lives on the Home tile grid and behind a push, so the dock
stays at six. There is no marketing site, no desktop layout and no tablet
layout; the app is a 520px column centred in whatever viewport it gets.

## Visual foundations

**One visual world, not two.** The app declares `color-scheme: dark` and does
not follow the OS theme. The metaphor is a scoreboard at night: bulb amber on
a dark board, chalk type, clay for trouble. Everything below follows from that.

**Colour.** Four values of night green carry structure — `--board` (#101A13,
the app), `--board-2` (#17231A, cards and the dock), `--board-3` (#1E2C21,
slot pills and tiles), `--rule` (#294032, every border). Type is chalk
(#EDEFE6) and chalk-dim (#8FA292). Three status colours and no more: grass
(#6FB06B) good, amber (#E8A33D) unknown, clay (#D2603F) trouble. **Amber is
not "warning" — it means not yet known**, which is the distinction the whole
product turns on. Nothing is ever tinted with a gradient; there are no
gradients in the product except the skeleton shimmer.

**Type.** Two cuts of Barlow, both from Google Fonts. Barlow sets prose.
Barlow Condensed, uppercase and tracked, sets everything that behaves like
signage: screen titles (32px/700), sheet names (26px), section labels
(11px/.16em), slate keys (10px/.12em), tab labels (9px), buttons, stat
columns, dates and every number. Numbers are tabular; rate stats print without
a leading zero (`.312`), ERA and WHIP to two decimals. Sizes include
half-pixels (13.5, 12.5, 10.5) — they are authored values, not rounding
errors, and should be copied as-is.

**Backgrounds.** Flat surface colour, always. No photography, no illustration,
no pattern, no texture, no full-bleed imagery anywhere in the product — the
only image assets are the app icons. When a screen has nothing to show it says
so in one sentence.

**Depth.** Hairlines and one step of surface value. `1px solid var(--rule)`
separates rows; cards are the same rule plus `--board-2`. There is no shadow
system: the single `box-shadow` in the app is an inset 3px amber bar marking
an unread suggestion. No blur, no transparency-and-blur chrome. The only
translucency is the sheet backdrop (black 55%) and two amber washes (8% for
the install banner, 25% for a switch track).

**The card.** One card shape: a ruled box, 7px radius, `--board-2` fill, with
a **3px status rule down the left edge** — clay, amber, grass or rule. That
left rule is the only place colour fills anything. Radii are otherwise small
and deliberate: 3px chips, 4px slot pills, 5px segments, 7px items, 8px cards
and buttons, and 16px for exactly two things, the home tile and the sheet.

**Motion.** Short, linear, unshowy. 150ms for switches and colour, 180ms for
the sheet backdrop fade, 220ms for the sheet's 14px rise on
`cubic-bezier(.2,.8,.3,1)`, 300ms for the settings pane sliding in from the
right. Nothing bounces, nothing scales on entry, and every animation has a
`prefers-reduced-motion` off-switch.

**Interaction states.** Press, not hover — this is a touch product. A tapped
row or card goes one surface step lighter (`--board-2` → `--board-3`) and
back; nothing moves or shrinks. Focus is a 2px amber ring, offset 2px (−2px or
−3px when it would otherwise be clipped). Selection is amber: the active tab
turns amber and grows a 2px amber top rule; a selected segment goes *darker*
than its track and its label turns amber. Disabled is the raised surface with
dim chalk and a rule border.

**Layout rules.** A single column, `max-width: 520px`, centred. The app frame
is a flex column: fixed strips at the top (preview bar, update pill, install
banner), one scrolling screen in the middle, the dock pinned at the bottom.
Screen padding is `10px 16px 24px`. Safe-area insets are claimed **once**, on
the app frame — a child that claims them again doubles the gap. Inputs are
locked at 16px, because below that iOS Safari zooms the whole page on focus.

## Content fundamentals

**Plain, factual, lower-case-sentence copy.** The app states what is true and
what it does not know. It never sells, never congratulates, never jokes.

- Titles are one or two words, sentence case in the source, uppercased by the
  type: "Today", "This week", "Keepers", "Transactions".
- Section labels are sentence case: "Needs a decision", "Check back before
  lock", "From your co-owner", "Still in play", "Decided".
- Verdicts are one sentence with the reason in it: "Scratched from tonight's
  lineup with hamstring tightness." "On the bench but in the lineup against a
  right-hander he is hitting .312 off."
- **Uncertainty is stated, not hidden.** "Not posted yet", "near coin flip",
  "It is an estimate from season rates, not a projection." Confidence is a
  percentage, and under 60% it says so in words.
- **Explanations sit next to the thing they explain**, in dim 13px prose:
  "Expected is his own season rate over the same 12 games — so an arrow means
  beating or trailing himself, not the league."
- It addresses the reader as *you* and never refers to itself as "we" or "I".
  Players are "he" and "him", because it is one person's baseball team.
- Numbers carry their unit or category abbreviation, never a bare figure.
- Required attribution, verbatim, at the foot of the screen: "Fantasy data
  provided by Yahoo Fantasy".
- **No emoji, anywhere.** No exclamation marks. No em-dash flourishes in UI
  strings — the app uses them only in explanatory prose.

## Iconography

Seven glyphs, drawn for this app on a 20×20 grid: stroke-only shapes,
1.4–1.7px, round caps and joins, `currentColor` so the wrapper decides colour.
That is the entire inventory — one per section — copied into `assets/icons/`
and wrapped by the `Icon` component. There is no icon font, no icon library,
and nothing from a CDN. If a new glyph is needed, draw it on the same grid at
the same weight rather than importing a set.

Four typographic marks do the remaining work, exactly as in the app: `‹` back,
`›` chevron, `×` close, `↻` refresh. Plus `▲ ▼ ·` for direction in a stat
table and `▾ ▸` for the install banner's disclosure. No emoji.

The app mark is a baseball: chalk leather with two clay seam arcs bowed in from
each side, clipped to the ball. It is drawn, not loaded — `assets/logo.svg`
transcribes `web/src/Logo.tsx`, and the same geometry generates the PNG app
icons in `web/make-icons.py`. Wordmark is simply BUNTS set in Barlow
Condensed 700 uppercase, with "UNRULY BUNTS" at .18em tracking beneath it.

## Index

| Path | What it is |
| --- | --- |
| `styles.css` | The entry point. Link this one file; it imports everything else. |
| `tokens/` | `colors` (dark + `[data-theme="light"]`), `typography`, `spacing`, `radius-border`, `motion`, `base`. |
| `guidelines/` | 18 specimen cards: colour, type, spacing, rules, motion, brand. |
| `assets/` | `logo.svg`, seven glyph SVGs + `icons.json`, and the installed app icons. |
| `components/` | 25 components in five groups — see below. |
| `ui_kits/bunts-pwa/` | Click-through recreation of the app. Start at `index.html`. |
| `dev-bundle.js` | Local shim so the cards render before the component bundle is built. |
| `github.md` | Repo association, last sync, screen map. |
| `SKILL.md` | Entry point when this folder is used as an agent skill. |

### Components

- **core** — `Button`, `Chip`, `Item` (+`ItemTop/Name/Meta/Verdict/Fix`),
  `SectionLabel`, `Slate` (+`SlateCell`), `Skeleton`, `Track`
- **data** — `PlayerRow`, `LineupLight`, `LineupState`, `FormStrip`, `CatRow`,
  `KeeperRow` (+`CutLine`), `CompareTable`, `GameLog`
- **forms** — `Switch` (+`ToggleRow`), `SegmentedControl`, `NoteInput` (+`Field`)
- **navigation** — `Icon` (+`Logo`), `TabBar`, `HomeTile` (+`HomeGrid`),
  `ScreenHeader`, `SetRow` (+`SetList`)
- **feedback** — `Sheet` (+`Tonight`), `InstallBanner` / `UpdatePill` /
  `PreviewBar`, `Stack` (+`StatusRow`, `Muted`)

The inventory is the app's own: every component here has a counterpart in
`web/src`. Nothing was added because a design system "usually" has one — there
is no Avatar, Tooltip, Toast, Modal, Accordion or Table, because the product
has none.

### Intentional additions

- **`Icon`** — the app's glyphs are seven separate React functions; a single
  name-driven wrapper is easier to consume. Same paths, same grid.
- **`Stack` / `StatusRow` / `Muted`** — the app's `.stack` and `.muted` CSS
  classes with no component of their own. Promoted so screens do not hand-roll
  them.

## Rules worth keeping

1. **`startingToday` is three-state: `true | false | null`.** Null means the
   lineup has not been posted. Rendering null as "not starting" is the worst
   failure this product can have, and it is the failure a boolean produces by
   default. Amber em dash, never clay.
2. **No write access.** Never design a flow that changes a roster. The app
   suggests; the user applies it in Yahoo.
3. **Attribution is mandatory** on any screen showing Yahoo data.
4. **Sample data is labelled.** The amber "Sample data" tag and the clay
   preview bar exist so a fixture build can never be mistaken for the league.

## Open items

- **Theme.** Dark is the app's committed default — it declares `color-scheme:
  dark` and says so at the top of its stylesheet. A **light theme** now ships
  alongside it: set `data-theme="light"` on `<html>` (or any ancestor) and the
  block at the foot of `tokens/colors.css` takes over. Board becomes paper,
  chalk becomes night-green ink, amber darkens to #A96C10 and `--ink` flips to
  white so type on an amber fill stays legible. No component changes — every
  status colour clears 4.5:1 on paper. The UI kit has a Light/Dark switch above
  the phone frame; the "Light theme" specimen card shows the palette.
- **Fonts.** Barlow and Barlow Condensed are loaded from Google Fonts, exactly
  as `web/index.html` does. No font binaries were provided and none are
  needed; if you want them self-hosted, drop the woff2 files in
  `assets/fonts/` and the `@font-face` rules will replace the remote import.
- **Keepers** has no scored list here, because the app's keeper formula is
  unfinished pending the league's scoring settings.
- Push notification styling is not in the repo's web code (the payload is
  built in `backend/src`), so no notification specimens were made.
