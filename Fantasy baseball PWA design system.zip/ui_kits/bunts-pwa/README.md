# Bunts PWA — UI kit

A click-through recreation of the installed web app (`web/src` in
`mackjohnson1014/bunts-app`), composed from this design system's components.

## Files

| File | What it is |
| --- | --- |
| `index.html` | Mounts the app in a 393x852 phone frame. Start here. |
| `screens.jsx` | All six surfaces plus the player sheet and the app shell. |
| `data.js` | Sample roster, calls, categories and transactions. Shapes follow `web/src/types.ts`. |

## What works

- Bottom dock switches between Home, Today, This Week, Roster, Keepers and Settings.
- Home tiles open the same sections; Transactions is reachable from Home, as in the app.
- Tapping any player row or any call on Today opens the player sheet; Escape or the
  backdrop closes it.
- The install banner expands and dismisses; the preview bar is always on, because the
  kit runs on sample data.

## What is deliberately thin

- **Keepers** shows a note instead of a list: the app's keeper formula is unfinished
  pending the league's scoring settings. The `KeeperRow` component is complete and
  demonstrated on the Data component card.
- **Settings** shows one toggle group and the section list rather than the app's full
  sliding section router.
- Nothing fetches. There is no Yahoo API access yet, so every number here is a stand-in.
