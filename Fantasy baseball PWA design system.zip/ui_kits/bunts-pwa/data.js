/* Sample data for the UI kit. Shapes follow web/src/types.ts; values are
   stand-ins in the spirit of the app's own mock fixtures. */
window.BUNTS_DATA = (() => {
  const g = (date, opponent, summary, quality) => ({ date, opponent, summary, quality });

  const players = [
    { playerKey: 'p1', name: 'Gunnar Henderson', mlbTeam: 'BAL', positions: ['SS', '3B'], slot: 'SS',
      status: null, startingToday: true, opponent: 'vs TOR', opposingPitcher: 'K. Gausman',
      seasonStats: { G: 148, R: 98, HR: 31, RBI: 84, SB: 19, AVG: .289 },
      last14Stats: { G: 12, R: 9, HR: 4, RBI: 11, SB: 1, AVG: .241 },
      percentOwned: 99, note: null,
      recentGames: [g('Sep 12', '@ SD', '2-4, HR, 2 RBI', 'good'), g('Sep 11', '@ SD', '0-4, 2 K', 'bad'),
        g('Sep 10', 'vs LAD', '1-3, BB', 'neutral'), g('Sep 09', 'vs LAD', 'Did not play', 'dnp'),
        g('Sep 08', 'vs SF', '3-5, 2B, R', 'good')] },

    { playerKey: 'p2', name: 'Bobby Witt Jr.', mlbTeam: 'KC', positions: ['SS'], slot: 'UTIL',
      status: 'DTD', startingToday: false, opponent: '@ CLE', opposingPitcher: 'T. Bibee',
      seasonStats: { G: 151, R: 104, HR: 27, RBI: 91, SB: 34, AVG: .315 },
      last14Stats: { G: 11, R: 6, HR: 1, RBI: 5, SB: 3, AVG: .268 },
      percentOwned: 100, note: 'Left the Wednesday game with hamstring tightness.',
      recentGames: [g('Sep 12', '@ CLE', 'Did not play', 'dnp'), g('Sep 11', '@ CLE', '1-4', 'neutral'),
        g('Sep 10', 'vs MIN', '2-4, SB', 'good'), g('Sep 09', 'vs MIN', '0-3', 'bad'),
        g('Sep 08', 'vs DET', '2-5, RBI', 'good')] },

    { playerKey: 'p3', name: 'Corbin Carroll', mlbTeam: 'ARI', positions: ['OF'], slot: 'OF',
      status: null, startingToday: true, opponent: 'vs COL', opposingPitcher: 'A. Senzatela',
      seasonStats: { G: 146, R: 91, HR: 24, RBI: 70, SB: 41, AVG: .268 },
      last14Stats: { G: 13, R: 11, HR: 2, RBI: 8, SB: 5, AVG: .311 },
      percentOwned: 98, note: null,
      recentGames: [g('Sep 12', 'vs COL', '2-4, SB', 'good'), g('Sep 11', 'vs COL', '1-4', 'neutral'),
        g('Sep 10', '@ SF', '3-4, HR', 'good'), g('Sep 09', '@ SF', '0-4', 'bad'),
        g('Sep 08', '@ SF', '1-3, BB, SB', 'good')] },

    { playerKey: 'p4', name: 'Adley Rutschman', mlbTeam: 'BAL', positions: ['C'], slot: 'C',
      status: null, startingToday: null, opponent: 'vs TOR', opposingPitcher: 'K. Gausman',
      seasonStats: { G: 139, R: 74, HR: 19, RBI: 76, SB: 1, AVG: .254 },
      last14Stats: { G: 10, R: 4, HR: 1, RBI: 6, SB: 0, AVG: .225 },
      percentOwned: 96, note: null,
      recentGames: [g('Sep 12', '@ SD', '1-4', 'neutral'), g('Sep 11', '@ SD', '0-3', 'bad'),
        g('Sep 10', 'vs LAD', '2-4, RBI', 'good'), g('Sep 09', 'vs LAD', 'Did not play', 'dnp'),
        g('Sep 08', 'vs SF', '1-4, BB', 'neutral')] },

    { playerKey: 'p5', name: 'Freddy Peralta', mlbTeam: 'MIL', positions: ['SP'], slot: 'SP',
      status: null, startingToday: null, opponent: '@ STL', opposingPitcher: null,
      seasonStats: { G: 31, W: 12, SV: 0, K: 198, ERA: 3.24, WHIP: 1.09 },
      last14Stats: { G: 3, W: 1, SV: 0, K: 22, ERA: 2.70, WHIP: 0.98 },
      percentOwned: 88, note: 'Probable starter tonight; the lineup card is not out yet.',
      recentGames: [g('Sep 11', '@ STL', '6.0 IP, 1 ER, 8 K', 'good'), g('Sep 06', 'vs CHC', '5.1 IP, 4 ER, 6 K', 'bad'),
        g('Sep 01', '@ PIT', '7.0 IP, 0 ER, 8 K', 'good'), g('Aug 27', 'vs CIN', '6.0 IP, 2 ER, 7 K', 'neutral')] },

    { playerKey: 'p6', name: 'Emmanuel Clase', mlbTeam: 'CLE', positions: ['RP'], slot: 'RP',
      status: null, startingToday: true, opponent: 'vs KC', opposingPitcher: null,
      seasonStats: { G: 68, W: 4, SV: 44, K: 71, ERA: 1.84, WHIP: 0.86 },
      last14Stats: { G: 6, W: 0, SV: 4, K: 7, ERA: 1.50, WHIP: 0.83 },
      percentOwned: 97, note: null,
      recentGames: [g('Sep 12', 'vs KC', '1.0 IP, SV', 'good'), g('Sep 10', 'vs MIN', '1.0 IP, SV', 'good'),
        g('Sep 08', '@ DET', '1.0 IP, 1 ER', 'bad'), g('Sep 06', '@ DET', '1.0 IP, SV', 'good')] },

    { playerKey: 'p7', name: 'Anthony Volpe', mlbTeam: 'NYY', positions: ['SS'], slot: 'BN',
      status: null, startingToday: true, opponent: '@ BOS', opposingPitcher: 'B. Bello',
      seasonStats: { G: 150, R: 82, HR: 14, RBI: 62, SB: 27, AVG: .251 },
      last14Stats: { G: 12, R: 8, HR: 2, RBI: 7, SB: 3, AVG: .295 },
      percentOwned: 71, note: null,
      recentGames: [g('Sep 12', '@ BOS', '2-4, RBI', 'good'), g('Sep 11', '@ BOS', '1-4, SB', 'neutral'),
        g('Sep 10', 'vs TB', '2-3, HR', 'good'), g('Sep 09', 'vs TB', '0-4', 'bad'),
        g('Sep 08', 'vs TB', '1-4', 'neutral')] },

    { playerKey: 'p8', name: 'Shane McClanahan', mlbTeam: 'TB', positions: ['SP'], slot: 'IL',
      status: 'IL60', startingToday: null, opponent: null, opposingPitcher: null,
      seasonStats: { G: 11, W: 4, SV: 0, K: 62, ERA: 3.58, WHIP: 1.14 },
      last14Stats: { G: 0 }, percentOwned: 54, note: 'Out for the season. Occupies an IL slot.',
      recentGames: [] },
  ];

  const calls = [
    { playerKey: 'p2', recommendation: 'sit', confidence: .93,
      reason: 'Scratched from tonight\u2019s lineup with hamstring tightness.' },
    { playerKey: 'p7', recommendation: 'start', confidence: .71,
      reason: 'On the bench but in the lineup against a right-hander he is hitting .312 off.' },
    { playerKey: 'p5', recommendation: 'hold', confidence: .55,
      reason: 'Probable, but the card is not posted. Check back before 7:05.' },
  ];

  const suggestions = [
    { id: 's1', playerName: 'Anthony Volpe', recommendation: 'start', authorName: 'Dave', createdAt: '2h', unread: true,
      note: 'Volpe over Witt tonight. Witt is not playing and Volpe is leading off.' },
  ];

  const categories = [
    { key: 'HR', label: 'Home runs', mine: 11, theirs: 9, status: 'live', leverage: .74, note: '+2 · close' },
    { key: 'SB', label: 'Steals', mine: 7, theirs: 6, status: 'live', leverage: .91, note: '+1 · coin flip' },
    { key: 'ERA', label: 'ERA', mine: '3.18', theirs: '2.94', status: 'live', leverage: .44, note: '\u2212.24 · within reach' },
    { key: 'R', label: 'Runs', mine: 41, theirs: 38, status: 'live', leverage: .62, note: '+3 · close' },
    { key: 'RBI', label: 'RBI', mine: 44, theirs: 31, status: 'won' },
    { key: 'AVG', label: 'Average', mine: '.281', theirs: '.253', status: 'won' },
    { key: 'W', label: 'Wins', mine: 3, theirs: 6, status: 'lost' },
    { key: 'K', label: 'Strikeouts', mine: 52, theirs: 61, status: 'lost' },
  ];

  const transactions = {
    opponentName: 'Sac Fly Guys', addsThisWeek: 3, cap: 4,
    opponentMoves: [
      { id: 't1', when: '3h', players: [{ name: 'Jordan Westburg', move: 'add' }, { name: 'Nick Gonzales', move: 'drop' }] },
      { id: 't2', when: '1d', players: [{ name: 'Bryan Abreu', move: 'add' }] },
    ],
    league: [
      { id: 't3', teamName: 'Foul Territory', when: '5h', players: [{ name: 'Jose Miranda', move: 'add' }] },
      { id: 't4', teamName: 'Balk This Way', when: '9h', players: [{ name: 'Mitch Keller', move: 'drop' }] },
      { id: 't5', teamName: 'Sac Fly Guys', when: '1d', players: [{ name: 'Bryan Abreu', move: 'add' }] },
    ],
  };

  return { players, calls, suggestions, categories, transactions,
    team: { name: 'Unruly Bunts', league: 'Unruly Bunts Keeper', rank: 3, week: 21, opponent: 'Sac Fly Guys', daysRemaining: 3 } };
})();
