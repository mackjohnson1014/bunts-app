/* Bunts PWA UI kit — the six surfaces, composed from the design system's
   components. Recreations of web/src/screens/*, not new designs. */

const DS = (() => {
  const named = window.Bunts || window.BuntsDesignSystem;
  if (named) return named;
  for (const k of Object.keys(window)) {
    const v = window[k];
    if (v && typeof v === 'object' && v.Button && v.Chip && v.PlayerRow) return v;
  }
  return {};
})();

const {
  Button, Chip, Item, ItemTop, ItemName, ItemMeta, ItemVerdict, ItemFix, SectionLabel,
  Slate, SlateCell, Track, PlayerRow, LineupState, FormStrip, CatRow, CompareTable, GameLog,
  SegmentedControl, NoteInput, ScreenHeader, TabBar, HomeTile, HomeGrid,
  Sheet, Tonight, Stack, StatusRow, Muted, InstallBanner, PreviewBar, isPitcher,
} = DS;

const D = window.BUNTS_DATA;
const byKey = Object.fromEntries(D.players.map((p) => [p.playerKey, p]));
const STARTING = ['C', '1B', '2B', '3B', 'SS', 'OF', 'UTIL', 'SP', 'RP', 'P'];

const ScreenBody = ({ children }) => (
  <div style={{ flex: 1, overflowY: 'auto', padding: '10px 16px 24px' }}>
    {children}
    <p style={{
      marginTop: 20, paddingTop: 12, borderTop: 'var(--hairline)',
      fontFamily: 'var(--font-condensed)', fontSize: 'var(--text-label)',
      letterSpacing: '.08em', textTransform: 'uppercase', color: 'var(--chalk-dim)',
    }}>Fantasy data provided by Yahoo Fantasy</p>
  </div>
);

/* ------------------------------- Home ------------------------------- */
function HomeScreen({ go }) {
  const sections = [
    ['today', 'Today'], ['week', 'This Week'], ['roster', 'Roster'],
    ['keepers', 'Keepers'], ['transactions', 'Transactions'], ['settings', 'Settings'],
  ];
  const icons = { today: 'today', week: 'week', roster: 'roster', keepers: 'keepers', transactions: 'transactions', settings: 'settings' };
  return (
    <ScreenBody>
      <ScreenHeader title="Home" />
      <HomeGrid>
        {sections.map(([id, label]) => <HomeTile key={id} icon={icons[id]} label={label} onClick={() => go(id)} />)}
      </HomeGrid>
    </ScreenBody>
  );
}

/* ------------------------------- Today ------------------------------ */
function TodayScreen({ onOpen }) {
  const active = D.players.filter((p) => STARTING.includes(p.slot));
  const counts = {
    active: active.length,
    in: active.filter((p) => p.startingToday === true).length,
    out: active.filter((p) => p.startingToday === false).length,
    unposted: active.filter((p) => p.startingToday === null).length,
  };
  const actionable = D.calls.filter((c) => c.recommendation !== 'hold');
  const holds = D.calls.filter((c) => c.recommendation === 'hold');

  return (
    <ScreenBody>
      <ScreenHeader
        title="Today"
        subtitle={<>Lineups lock at 7:05 PM · <strong style={{ color: 'var(--clay)' }}>42 min</strong></>}
        updated="4m ago" sample onReload={() => {}}
      />
      <Slate>
        <SlateCell value={counts.active} label="Active" />
        <SlateCell value={counts.in} label="In" color="var(--grass)" />
        <SlateCell value={counts.out} label="Out" color="var(--clay)" />
        <SlateCell value={counts.unposted} label="Unposted" color="var(--amber)" last />
      </Slate>

      <SectionLabel first>From your co-owner · 1 new</SectionLabel>
      {D.suggestions.map((s) => (
        <Item key={s.id} tone="ok" unread={s.unread}>
          <ItemTop>
            <ItemName>{s.playerName}</ItemName>
            <Chip tone="in">Start</Chip>
            <ItemMeta>{s.authorName} · {s.createdAt}</ItemMeta>
          </ItemTop>
          <ItemVerdict>{s.note}</ItemVerdict>
        </Item>
      ))}

      <SectionLabel>Needs a decision</SectionLabel>
      {actionable.map((c) => <Call key={c.playerKey} call={c} onOpen={onOpen} />)}

      <SectionLabel>Check back before lock</SectionLabel>
      {holds.map((c) => <Call key={c.playerKey} call={c} onOpen={onOpen} />)}
    </ScreenBody>
  );
}

function Call({ call, onOpen }) {
  const p = byKey[call.playerKey];
  const tone = call.recommendation === 'sit' ? 'critical' : call.recommendation === 'start' ? 'ok' : 'pending';
  const chip = call.recommendation === 'sit' ? ['out', 'Sit'] : call.recommendation === 'start' ? ['in', 'Start'] : ['unknown', 'Wait'];
  return (
    <Item tone={tone} as="button" onClick={() => onOpen(p)}>
      <ItemTop>
        <ItemName>{p.name}</ItemName>
        <Chip tone={chip[0]}>{chip[1]}</Chip>
        <ItemMeta>{p.positions[0]}{p.opponent ? ' · ' + p.opponent : ''}</ItemMeta>
      </ItemTop>
      <ItemVerdict>{call.reason}</ItemVerdict>
      <ItemFix>
        <LineupState starting={p.startingToday} />
        <FormStrip games={p.recentGames} />
        <span style={{ color: 'var(--chalk-dim)', fontSize: 'var(--text-meta)' }}>
          {Math.round(call.confidence * 100)}%{call.confidence < .6 ? ' — near coin flip' : ''}
        </span>
        <span aria-hidden="true" style={{ color: 'var(--chalk-dim)', marginLeft: 'auto', fontSize: 18, lineHeight: 1 }}>›</span>
      </ItemFix>
    </Item>
  );
}

/* ------------------------------- Week ------------------------------- */
function WeekScreen() {
  const live = D.categories.filter((c) => c.status === 'live' || c.status === 'tied');
  const won = D.categories.filter((c) => c.status === 'won');
  const lost = D.categories.filter((c) => c.status === 'lost');
  return (
    <ScreenBody>
      <ScreenHeader
        title="This week"
        subtitle={'Week ' + D.team.week + ' vs ' + D.team.opponent + ' · ' + D.team.daysRemaining + ' days left'}
        sample onReload={() => {}}
      />
      <Slate>
        <SlateCell value={won.length} label="Won" color="var(--grass)" />
        <SlateCell value={live.length} label="Live" color="var(--amber)" />
        <SlateCell value={lost.length} label="Lost" color="var(--clay)" />
        <SlateCell value={D.categories.length} label="Cats" last />
      </Slate>
      <Muted style={{ marginBottom: 4 }}>
        {live.length} categories are still in play — those are the only ones a lineup change can move.
      </Muted>
      <SectionLabel>Still in play</SectionLabel>
      {live.map((c) => <CatRow key={c.key} catKey={c.key} label={c.label} mine={c.mine} theirs={c.theirs} status={c.status} leverage={c.leverage} note={c.note} />)}
      <SectionLabel>Decided</SectionLabel>
      {won.concat(lost).map((c) => <CatRow key={c.key} catKey={c.key} label={c.label} mine={c.mine} theirs={c.theirs} status={c.status} />)}
      <Muted style={{ marginTop: 14 }}>
        "Still in play" means the gap is within reach of what your active roster can produce in the days left.
        It is an estimate from season rates, not a projection.
      </Muted>
    </ScreenBody>
  );
}

/* ------------------------------ Roster ------------------------------ */
function RosterScreen({ onOpen }) {
  const rank = (p) => (STARTING.includes(p.slot) ? 0 : p.slot === 'BN' ? 1 : 2);
  const order = (list) => [...list].sort((a, b) => rank(a) - rank(b));
  const hitters = order(D.players.filter((p) => !isPitcher(p)));
  const pitchers = order(D.players.filter((p) => isPitcher(p)));
  return (
    <ScreenBody>
      <ScreenHeader
        title={D.team.name}
        subtitle={D.team.league + ' · 3rd place'}
        updated="4m ago" sample onReload={() => {}}
      />
      <SectionLabel first>Hitters</SectionLabel>
      {hitters.map((p) => <PlayerRow key={p.playerKey} player={p} onOpen={onOpen} />)}
      <SectionLabel>Pitchers</SectionLabel>
      {pitchers.map((p) => <PlayerRow key={p.playerKey} player={p} onOpen={onOpen} />)}
    </ScreenBody>
  );
}

/* --------------------------- Transactions --------------------------- */
function TransactionsScreen() {
  const t = D.transactions;
  const remaining = Math.max(0, t.cap - t.addsThisWeek);
  return (
    <ScreenBody>
      <ScreenHeader title="Transactions" subtitle={'This week vs ' + t.opponentName} updated="12m ago" sample onReload={() => {}} />
      <Stack>
        <p style={{ margin: 0 }}>
          <strong>{t.opponentName}</strong> has made <strong>{t.addsThisWeek}</strong> of {t.cap} adds this week
        </p>
        <Track value={Math.round((t.addsThisWeek / t.cap) * 100)} color="var(--amber)" style={{ marginTop: 10 }} />
        <Muted style={{ margin: '8px 0 0' }}>{remaining} add left before the weekly cap resets.</Muted>
      </Stack>
      <SectionLabel>{t.opponentName}'s moves this week</SectionLabel>
      {t.opponentMoves.map((x) => <Txn key={x.id} txn={x} />)}
      <SectionLabel>League activity</SectionLabel>
      {t.league.map((x) => <Txn key={x.id} txn={x} showTeam />)}
    </ScreenBody>
  );
}

function Txn({ txn, showTeam }) {
  return (
    <Item tone="plain">
      <ItemTop>
        {showTeam ? <ItemName>{txn.teamName}</ItemName> : null}
        <ItemMeta>{txn.when}</ItemMeta>
      </ItemTop>
      {txn.players.map((p) => (
        <ItemVerdict key={p.name} style={showTeam ? undefined : { marginTop: 0 }}>
          <Chip tone={p.move === 'add' ? 'in' : 'out'}>{p.move === 'add' ? 'Add' : 'Drop'}</Chip> {p.name}
        </ItemVerdict>
      ))}
    </Item>
  );
}

/* --------------------------- Player sheet --------------------------- */
function PlayerDetail({ player, onClose }) {
  const [rec, setRec] = React.useState('start');
  if (!player) return null;
  const pitcher = isPitcher(player);
  const keys = pitcher ? ['W', 'SV', 'K', 'ERA', 'WHIP'] : ['R', 'HR', 'RBI', 'SB', 'AVG'];
  const RATE = ['AVG', 'ERA', 'WHIP'];
  const seasonG = player.seasonStats.G || 0;
  const recentG = player.last14Stats.G || 0;

  const fmt = (v) => (v === undefined ? '–' : v < 10 && !Number.isInteger(v) ? v.toFixed(3).replace(/^0/, '') : String(v));
  const rows = keys.map((k) => {
    const season = player.seasonStats[k];
    const recent = player.last14Stats[k];
    const expected = RATE.includes(k) ? season
      : seasonG && recentG && season !== undefined ? Math.round((season / seasonG) * recentG * 10) / 10 : undefined;
    let direction = 'flat';
    if (expected !== undefined && recent !== undefined && expected !== 0) {
      const delta = (recent - expected) / Math.abs(expected);
      if (Math.abs(delta) >= .05) {
        const lowerBetter = k === 'ERA' || k === 'WHIP';
        direction = (lowerBetter ? delta < 0 : delta > 0) ? 'up' : 'down';
      }
    }
    return { key: k, actual: fmt(recent), expected: expected === undefined ? '–' : fmt(expected), direction };
  });

  const status = player.startingToday === true ? ['In the lineup', 'good']
    : player.startingToday === false ? ['Not starting', 'bad'] : ['Not posted yet', 'warn'];

  return (
    <Sheet
      title={player.name}
      meta={player.mlbTeam + ' · ' + player.positions.join('/') + ' · slot ' + player.slot + ' · ' + player.percentOwned + '% rostered'}
      onClose={onClose}
    >
      <SectionLabel>Tonight</SectionLabel>
      <Tonight cells={[
        { label: 'Status', value: status[0], tone: status[1] },
        { label: 'Opponent', value: player.opponent || 'No game' },
        { label: pitcher ? 'Role' : 'Opposing SP', value: pitcher ? (player.startingToday ? 'Starting' : 'Bullpen') : (player.opposingPitcher || '—') },
      ]} />

      {player.note ? (
        <div style={{ marginTop: 12 }}>
          <Item tone="pending"><ItemVerdict style={{ marginTop: 0 }}>{player.note}</ItemVerdict></Item>
        </div>
      ) : null}

      <SectionLabel>Last 14 days</SectionLabel>
      <CompareTable rows={rows} />
      <Muted style={{ marginTop: 6 }}>
        Expected is his own season rate over the same {recentG} games — so an arrow means beating or trailing himself, not the league.
      </Muted>

      <SectionLabel>Last five games</SectionLabel>
      {player.recentGames.length === 0
        ? <Muted>No recent appearances.</Muted>
        : <><FormStrip games={player.recentGames} /><GameLog games={player.recentGames} /></>}

      <SectionLabel>Tell your co-owner</SectionLabel>
      <SegmentedControl
        aria-label="Recommendation" value={rec} onChange={setRec}
        options={[{ id: 'start', label: 'Start him' }, { id: 'sit', label: 'Sit him' }, { id: 'watch', label: 'Keep an eye' }]}
      />
      <NoteInput rows={2} maxLength={280} placeholder={'Why ' + player.name.split(' ')[0] + '? (optional)'} />
      <div style={{ marginTop: 12 }}><Button>Send suggestion</Button></div>
    </Sheet>
  );
}

/* -------------------------------- App -------------------------------- */
function App() {
  const [tab, setTab] = React.useState('today');
  const [player, setPlayer] = React.useState(null);
  const [install, setInstall] = React.useState(false);
  const [dismissed, setDismissed] = React.useState(false);

  return (
    <div style={{
      position: 'relative', display: 'flex', flexDirection: 'column', height: '100%',
      maxWidth: 'var(--app-max-width)', margin: '0 auto', background: 'var(--board)', overflow: 'hidden',
    }}>
      <PreviewBar />
      {dismissed ? null : (
        <InstallBanner
          open={install}
          onToggle={() => setInstall((o) => !o)}
          onDismiss={() => setDismissed(true)}
          steps={['Tap the Share button', 'Tap Add to Home Screen', 'Open Bunts from the home screen']}
        />
      )}

      {tab === 'home' && <HomeScreen go={setTab} />}
      {tab === 'today' && <TodayScreen onOpen={setPlayer} />}
      {tab === 'week' && <WeekScreen />}
      {tab === 'roster' && <RosterScreen onOpen={setPlayer} />}
      {tab === 'keepers' && <KeepersPlaceholder />}
      {tab === 'transactions' && <TransactionsScreen />}
      {tab === 'settings' && <SettingsPlaceholder />}

      <TabBar value={tab} onChange={setTab} />
      <PlayerDetail player={player} onClose={() => setPlayer(null)} />
    </div>
  );
}

function KeepersPlaceholder() {
  return (
    <ScreenBody>
      <ScreenHeader title="Keepers" subtitle="Running tally · 4 slots next season" sample />
      <Stack><Muted>Keeper scoring is unfinished in the app — the formula needs the league's scoring settings and keeper rules. The row component is in the Data card.</Muted></Stack>
    </ScreenBody>
  );
}

function SettingsPlaceholder() {
  const [on, setOn] = React.useState(true);
  const { SetList, SetRow, ToggleRow } = DS;
  return (
    <ScreenBody>
      <ScreenHeader title="Settings" />
      <SectionLabel first>Alerts</SectionLabel>
      <Stack>
        <ToggleRow title="Scratched from the lineup" description="When an active player is out tonight." checked={on} onChange={setOn} last />
      </Stack>
      <SectionLabel>Sections</SectionLabel>
      <SetList>
        <SetRow icon="settings" label="Notifications" value="4 on" />
        <SetRow icon="roster" label="Your profile" value="Mack" last />
      </SetList>
    </ScreenBody>
  );
}

window.BuntsKit = { App };
